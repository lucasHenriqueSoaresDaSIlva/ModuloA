USE senn_med_ai;

INSERT INTO care_resources (code, sector, type, equipment_json, status, next_maintenance_date, notes) VALUES
('CONS-01','Pronto Atendimento A','consultorio',JSON_ARRAY('Oxímetro','Esfigmomanômetro'),'livre',DATE_ADD(CURDATE(), INTERVAL 60 DAY),'Consultório clínico'),
('CONS-02','Pronto Atendimento A','consultorio',JSON_ARRAY('Oxímetro','ECG portátil'),'livre',DATE_ADD(CURDATE(), INTERVAL 5 DAY),'Consultório de apoio'),
('OBS-01','Observação','observacao',JSON_ARRAY('Monitor multiparamétrico','Oxigênio'),'livre',DATE_ADD(CURDATE(), INTERVAL 45 DAY),'Leito de observação'),
('OBS-02','Observação','observacao',JSON_ARRAY('Monitor multiparamétrico','Oxigênio'),'higienizacao',DATE_ADD(CURDATE(), INTERVAL 40 DAY),'Em higienização de demonstração'),
('UTI-01','Unidade Crítica','uti',JSON_ARRAY('Ventilador','Monitor multiparamétrico','Bomba de infusão'),'livre',DATE_ADD(CURDATE(), INTERVAL 30 DAY),'Leito crítico'),
('ISO-01','Isolamento','isolamento',JSON_ARRAY('Pressão negativa','Oxigênio'),'livre',DATE_ADD(CURDATE(), INTERVAL 90 DAY),'Leito de isolamento');

UPDATE care_resources SET cleaning_started_at = DATE_SUB(NOW(), INTERVAL 50 MINUTE) WHERE code='OBS-02';

INSERT INTO professionals (name, registration_type, registration_number, registration_expires_at, specialty, contact, shift_label, availability_status, care_resource_id) VALUES
('Dra. Ana Ribeiro','CRM','CRM-SP-100001',DATE_ADD(CURDATE(), INTERVAL 365 DAY),'Clínica Geral','ana.ribeiro@sennmed.local','07:00-19:00','disponivel',1),
('Dr. Bruno Costa','CRM','CRM-SP-100002',DATE_ADD(CURDATE(), INTERVAL 20 DAY),'Cardiologia','bruno.costa@sennmed.local','07:00-19:00','disponivel',2),
('Enf. Camila Souza','COREN','COREN-SP-200001',DATE_ADD(CURDATE(), INTERVAL 300 DAY),'Triagem','camila.souza@sennmed.local','07:00-19:00','disponivel',NULL),
('Dra. Daniela Lima','CRM','CRM-SP-100003',DATE_ADD(CURDATE(), INTERVAL 500 DAY),'Pediatria','daniela.lima@sennmed.local','19:00-07:00','indisponivel',NULL);

INSERT INTO users (name,email,password_hash,role,professional_id,status) VALUES
('Administrador SENN','admin@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$WEhHekRCTEpzalozS0I1dg$bCEaqd+COPiwQYyzmKvCInyPwgYxxwDJHvdrEE91TPk','admin',NULL,'active'),
('Dra. Ana Ribeiro','medico@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$Lnh2M0F6VDBZdzhoMnVIeA$1mqdbMaJLuRon0Ug4jhIgx5H/UL6twuy3r3w2UK65cw','doctor',1,'active'),
('Enf. Camila Souza','enfermeiro@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$Lnh2M0F6VDBZdzhoMnVIeA$1mqdbMaJLuRon0Ug4jhIgx5H/UL6twuy3r3w2UK65cw','nurse',3,'active'),
('Recepção Central','recepcao@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$Lnh2M0F6VDBZdzhoMnVIeA$1mqdbMaJLuRon0Ug4jhIgx5H/UL6twuy3r3w2UK65cw','receptionist',NULL,'active');

INSERT INTO patients (medical_record_no,name,cpf_enc,cpf_hash,birth_date,gender,insurance,allergies_enc,comorbidities_enc,consent_given,consent_at,created_by) VALUES
('PR-2026-0001','Marcos Almeida','LRpWGq/BV/416zza1dMLjFQpEO5oNn7IjZhyXg0NfN2P/layESnRI9Mp','f358161d1ccfc3df09d9d379bfc4458f5994834db765166fd1202b3d0192a293','1978-04-12','M','SENN Saúde','L4uQbBIF+W1HQIrjLCiroEcms2+QYzTE/T1gPhkHfbJxohTX','1igKkyU6gD+IARKB3trY6W+UdCJnUwPycslyqvBv53NUw9ZcfshMeQ==',1,NOW(),4),
('PR-2026-0002','Juliana Martins','dnHlLWKTtSLTvuUKUBzmpN222bRJq2LW3ts9Drz5ox/ej8BOl7AP7Xyx','716035db87c32a05f9b60f41a7fbc70c4c57fb32448f90553fec4bc5a9cc8ac8','1991-09-21','F','Particular','C9gu7Vyi2QksnZMyTX3AExEQLQoy9pzrvu0kP5+nRSokwSjqP+RtfxsULabMuHLPB0UwNfA=','WD0Pap3fYtiJH5H4+Nzh/5f38+OEoPx2L8ncNmQimHNIdWNtg79rrZgjIg==',1,NOW(),4),
('PR-2026-0003','Rafael Nunes','DuPLZe0JAI5ASp+8bQd0gnH9sAUb8vOGZzuje2hxCrg7eZayK+Y3g5oV','b30c358573fbdb64626c9ffa3012c9bede3007af7aa8d63c700910b60a865791','2004-02-03','M','SENN Saúde','U2JV8Pft7lTLNI0hVBWKA2kGj76qFMXKCebEI+LNc3yDP7Mb5ag=','u/3lsVALrPJ67LZBB8a9Zmjb9TpEtQo0SLph545u6xM=',1,NOW(),4);

INSERT INTO encounters (patient_id,chief_complaint_enc,systolic,diastolic,temperature,heart_rate,spo2,status,checkin_at) VALUES
(1,'LL6CeI/HypB5r3rPK10JFbPQzK1b7CHinuVDelt/WBOGuGYJ7D0yARBfJXToYWoQggS2sfMm',92,61,37.4,128,92,'aguardando_triagem',DATE_SUB(NOW(), INTERVAL 8 MINUTE)),
(2,'XdhyPF5yWvT0RcAFNhGrwYnxajRL9DTNaKpl8imxiZQpEqEKvueH6z3jf4YEKg==',118,77,39.2,108,95,'aguardando_triagem',DATE_SUB(NOW(), INTERVAL 25 MINUTE)),
(3,'kzl3Esj8yQ16t+HGlQvjhgnOnkreblsEvvb2Sk8NMbGpNVwG2+dSCmxF2T0fQI6VCKddspVYnYGWDmbttg==',122,80,36.7,78,98,'aguardando_triagem',DATE_SUB(NOW(), INTERVAL 12 MINUTE));

-- Histórico agregado realista para previsão e dashboard. Dados clínicos livres não são necessários nesses registros.
INSERT INTO patients (medical_record_no,name,birth_date,gender,insurance,consent_given,consent_at,created_by)
SELECT CONCAT('HIST-', LPAD(n,4,'0')), CONCAT('Paciente Histórico ', n), DATE_SUB(CURDATE(), INTERVAL (20+n) YEAR), IF(MOD(n,2)=0,'F','M'), 'SENN Saúde', 1, DATE_SUB(NOW(), INTERVAL n DAY), 4
FROM (
  SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10 UNION
  SELECT 11 UNION SELECT 12 UNION SELECT 13 UNION SELECT 14 UNION SELECT 15 UNION SELECT 16 UNION SELECT 17 UNION SELECT 18 UNION SELECT 19 UNION SELECT 20 UNION
  SELECT 21 UNION SELECT 22 UNION SELECT 23 UNION SELECT 24 UNION SELECT 25 UNION SELECT 26 UNION SELECT 27 UNION SELECT 28 UNION SELECT 29 UNION SELECT 30
) seq;

INSERT INTO encounters (patient_id,chief_complaint_enc,systolic,diastolic,temperature,heart_rate,spo2,specialty_hint,status,priority_color,priority_label,max_wait_minutes,checkin_at,care_started_at,discharged_at)
SELECT p.id, '', 120,80,36.8,80,98,
       CASE MOD(p.id,4) WHEN 0 THEN 'Clínica Geral' WHEN 1 THEN 'Cardiologia' WHEN 2 THEN 'Pediatria' ELSE 'Ortopedia' END,
       'alta',
       CASE MOD(p.id,5) WHEN 0 THEN 'vermelho' WHEN 1 THEN 'laranja' WHEN 2 THEN 'amarelo' WHEN 3 THEN 'verde' ELSE 'azul' END,
       CASE MOD(p.id,5) WHEN 0 THEN 'Emergência' WHEN 1 THEN 'Muito Urgente' WHEN 2 THEN 'Urgente' WHEN 3 THEN 'Pouco Urgente' ELSE 'Não Urgente' END,
       CASE MOD(p.id,5) WHEN 0 THEN 0 WHEN 1 THEN 10 WHEN 2 THEN 60 WHEN 3 THEN 120 ELSE 240 END,
       DATE_SUB(NOW(), INTERVAL (p.id-3) DAY),
       DATE_ADD(DATE_SUB(NOW(), INTERVAL (p.id-3) DAY), INTERVAL (5 + MOD(p.id,30)) MINUTE),
       DATE_ADD(DATE_SUB(NOW(), INTERVAL (p.id-3) DAY), INTERVAL (60 + MOD(p.id,240)) MINUTE)
FROM patients p WHERE p.medical_record_no LIKE 'HIST-%';

INSERT INTO hygiene_events (care_resource_id, started_at) SELECT id, cleaning_started_at FROM care_resources WHERE status='higienizacao';
