CREATE DATABASE IF NOT EXISTS senn_med_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE senn_med_ai;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS notification_logs;
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS hygiene_events;
DROP TABLE IF EXISTS clinical_outcomes;
DROP TABLE IF EXISTS triage_assessments;
DROP TABLE IF EXISTS encounters;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS ai_logs;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS professionals;
DROP TABLE IF EXISTS care_resources;

CREATE TABLE care_resources (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    sector VARCHAR(100) NOT NULL,
    type ENUM('consultorio','observacao','uti','isolamento') NOT NULL,
    equipment_json JSON NULL,
    status ENUM('livre','ocupado','higienizacao','manutencao') NOT NULL DEFAULT 'livre',
    next_maintenance_date DATE NULL,
    cleaning_started_at DATETIME NULL,
    notes VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_resource_sector_status (sector, status),
    INDEX idx_resource_type_status (type, status),
    INDEX idx_resource_maintenance (next_maintenance_date)
) ENGINE=InnoDB;

CREATE TABLE professionals (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    registration_type ENUM('CRM','COREN') NOT NULL,
    registration_number VARCHAR(40) NOT NULL UNIQUE,
    registration_expires_at DATE NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    contact VARCHAR(150) NULL,
    shift_label VARCHAR(100) NOT NULL,
    availability_status ENUM('disponivel','ocupado','indisponivel') NOT NULL DEFAULT 'disponivel',
    care_resource_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_prof_resource FOREIGN KEY (care_resource_id) REFERENCES care_resources(id) ON DELETE SET NULL,
    INDEX idx_prof_specialty_available (specialty, availability_status),
    INDEX idx_prof_expiry (registration_expires_at)
) ENGINE=InnoDB;

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','doctor','nurse','receptionist') NOT NULL,
    professional_id BIGINT UNSIGNED NULL UNIQUE,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_user_prof FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE SET NULL,
    INDEX idx_user_role_status (role, status)
) ENGINE=InnoDB;

CREATE TABLE patients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    medical_record_no VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    cpf_enc TEXT NULL,
    cpf_hash CHAR(64) NULL UNIQUE,
    birth_date DATE NOT NULL,
    gender ENUM('F','M','O','N') NOT NULL DEFAULT 'N',
    insurance VARCHAR(120) NULL,
    allergies_enc TEXT NULL,
    comorbidities_enc TEXT NULL,
    consent_given TINYINT(1) NOT NULL DEFAULT 0,
    consent_purpose VARCHAR(255) NOT NULL DEFAULT 'Atendimento assistencial e gestão hospitalar',
    consent_at DATETIME NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_patient_creator FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_patient_name (name),
    INDEX idx_patient_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE encounters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT UNSIGNED NOT NULL,
    chief_complaint_enc TEXT NOT NULL,
    systolic SMALLINT UNSIGNED NOT NULL,
    diastolic SMALLINT UNSIGNED NOT NULL,
    temperature DECIMAL(4,1) NOT NULL,
    heart_rate SMALLINT UNSIGNED NOT NULL,
    spo2 TINYINT UNSIGNED NOT NULL,
    specialty_hint VARCHAR(100) NULL,
    status ENUM('aguardando_triagem','aguardando_medico','em_atendimento','medicacao','alta') NOT NULL DEFAULT 'aguardando_triagem',
    priority_color ENUM('vermelho','laranja','amarelo','verde','azul') NULL,
    priority_label VARCHAR(50) NULL,
    max_wait_minutes SMALLINT UNSIGNED NULL,
    triage_confirmed_by BIGINT UNSIGNED NULL,
    triage_confirmed_at DATETIME NULL,
    assigned_professional_id BIGINT UNSIGNED NULL,
    assigned_resource_id BIGINT UNSIGNED NULL,
    checkin_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    care_started_at DATETIME NULL,
    discharged_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_enc_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
    CONSTRAINT fk_enc_triage_user FOREIGN KEY (triage_confirmed_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_enc_prof FOREIGN KEY (assigned_professional_id) REFERENCES professionals(id) ON DELETE SET NULL,
    CONSTRAINT fk_enc_resource FOREIGN KEY (assigned_resource_id) REFERENCES care_resources(id) ON DELETE SET NULL,
    INDEX idx_enc_status_priority_wait (status, priority_color, checkin_at),
    INDEX idx_enc_prof_status (assigned_professional_id, status),
    INDEX idx_enc_resource_status (assigned_resource_id, status),
    INDEX idx_enc_checkin (checkin_at),
    INDEX idx_enc_discharged (discharged_at)
) ENGINE=InnoDB;

CREATE TABLE triage_assessments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    encounter_id BIGINT UNSIGNED NOT NULL,
    suggested_color ENUM('vermelho','laranja','amarelo','verde','azul') NOT NULL,
    confirmed_color ENUM('vermelho','laranja','amarelo','verde','azul') NOT NULL,
    nurse_user_id BIGINT UNSIGNED NOT NULL,
    override_reason VARCHAR(500) NULL,
    rules_json JSON NOT NULL,
    ai_suggestion_text TEXT NULL,
    ai_status ENUM('available','fallback','disabled','error') NOT NULL DEFAULT 'fallback',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_triage_enc FOREIGN KEY (encounter_id) REFERENCES encounters(id) ON DELETE CASCADE,
    CONSTRAINT fk_triage_nurse FOREIGN KEY (nurse_user_id) REFERENCES users(id),
    INDEX idx_triage_enc_created (encounter_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE clinical_outcomes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    encounter_id BIGINT UNSIGNED NOT NULL UNIQUE,
    diagnosis_cid VARCHAR(20) NOT NULL,
    clinical_notes_enc MEDIUMTEXT NOT NULL,
    prescription_enc MEDIUMTEXT NULL,
    attachment_path VARCHAR(255) NULL,
    attachment_original_name VARCHAR(255) NULL,
    attachment_mime VARCHAR(100) NULL,
    physician_user_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_outcome_enc FOREIGN KEY (encounter_id) REFERENCES encounters(id) ON DELETE CASCADE,
    CONSTRAINT fk_outcome_doc FOREIGN KEY (physician_user_id) REFERENCES users(id),
    INDEX idx_outcome_doc_created (physician_user_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE hygiene_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    care_resource_id BIGINT UNSIGNED NOT NULL,
    encounter_id BIGINT UNSIGNED NULL,
    started_at DATETIME NOT NULL,
    completed_at DATETIME NULL,
    completed_by BIGINT UNSIGNED NULL,
    notes VARCHAR(500) NULL,
    CONSTRAINT fk_hygiene_resource FOREIGN KEY (care_resource_id) REFERENCES care_resources(id),
    CONSTRAINT fk_hygiene_enc FOREIGN KEY (encounter_id) REFERENCES encounters(id) ON DELETE SET NULL,
    CONSTRAINT fk_hygiene_user FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_hygiene_open (completed_at, started_at)
) ENGINE=InnoDB;

CREATE TABLE alerts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    type ENUM('wait_time','hygiene','occupancy','maintenance','professional_expiry','clinical_risk') NOT NULL,
    severity ENUM('info','warning','critical') NOT NULL,
    message VARCHAR(600) NOT NULL,
    entity_type VARCHAR(60) NULL,
    entity_id BIGINT UNSIGNED NULL,
    fingerprint CHAR(64) NOT NULL,
    resolved_at DATETIME NULL,
    resolved_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_alert_resolver FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_openish_fingerprint_created (fingerprint, created_at),
    INDEX idx_alert_open_type (resolved_at, type),
    INDEX idx_alert_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE notification_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alert_id BIGINT UNSIGNED NOT NULL,
    channel ENUM('panel','email') NOT NULL,
    recipient VARCHAR(190) NULL,
    status ENUM('sent','logged','failed') NOT NULL,
    detail VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_alert FOREIGN KEY (alert_id) REFERENCES alerts(id) ON DELETE CASCADE,
    INDEX idx_notification_alert (alert_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(80) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id BIGINT UNSIGNED NULL,
    purpose VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NULL,
    metadata_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_user_created (user_id, created_at),
    INDEX idx_audit_entity_created (entity_type, entity_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE ai_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    module VARCHAR(60) NOT NULL,
    provider VARCHAR(40) NOT NULL,
    model VARCHAR(100) NULL,
    status ENUM('success','fallback','disabled','error') NOT NULL,
    latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
    prompt_hash CHAR(64) NULL,
    request_meta_json JSON NULL,
    response_excerpt VARCHAR(1000) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ai_module_created (module, created_at),
    INDEX idx_ai_status_created (status, created_at)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
