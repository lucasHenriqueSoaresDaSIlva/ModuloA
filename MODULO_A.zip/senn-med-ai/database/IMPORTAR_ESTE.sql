-- SENN MED-AI - INSTALACAO COMPLETA PARA XAMPP
-- Importe somente este arquivo pelo phpMyAdmin.

CREATE DATABASE IF NOT EXISTS senn_med_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE senn_med_ai;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS notification_logs;
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS hygiene_events;
DROP TABLE IF EXISTS clinical_outcomes;
DROP TABLE IF EXISTS triage_assessments;
DROP TABLE IF EXISTS encounters;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS ai_logs;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS professionals;
DROP TABLE IF EXISTS care_resources;

CREATE TABLE care_resources (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    sector VARCHAR(100) NOT NULL,
    type ENUM('consultorio','observacao','uti','isolamento') NOT NULL,
    equipment_json JSON NULL,
    status ENUM('livre','ocupado','higienizacao','manutencao') NOT NULL DEFAULT 'livre',
    next_maintenance_date DATE NULL,
    cleaning_started_at DATETIME NULL,
    notes VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_resource_sector_status (sector, status),
    INDEX idx_resource_type_status (type, status),
    INDEX idx_resource_maintenance (next_maintenance_date)
) ENGINE=InnoDB;

CREATE TABLE professionals (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    registration_type ENUM('CRM','COREN') NOT NULL,
    registration_number VARCHAR(40) NOT NULL UNIQUE,
    registration_expires_at DATE NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    contact VARCHAR(150) NULL,
    shift_label VARCHAR(100) NOT NULL,
    availability_status ENUM('disponivel','ocupado','indisponivel') NOT NULL DEFAULT 'disponivel',
    care_resource_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_prof_resource FOREIGN KEY (care_resource_id) REFERENCES care_resources(id) ON DELETE SET NULL,
    INDEX idx_prof_specialty_available (specialty, availability_status),
    INDEX idx_prof_expiry (registration_expires_at)
) ENGINE=InnoDB;

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','doctor','nurse','receptionist') NOT NULL,
    professional_id BIGINT UNSIGNED NULL UNIQUE,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_user_prof FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE SET NULL,
    INDEX idx_user_role_status (role, status)
) ENGINE=InnoDB;

CREATE TABLE patients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    medical_record_no VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    cpf_enc TEXT NULL,
    cpf_hash CHAR(64) NULL UNIQUE,
    birth_date DATE NOT NULL,
    gender ENUM('F','M','O','N') NOT NULL DEFAULT 'N',
    insurance VARCHAR(120) NULL,
    allergies_enc TEXT NULL,
    comorbidities_enc TEXT NULL,
    consent_given TINYINT(1) NOT NULL DEFAULT 0,
    consent_purpose VARCHAR(255) NOT NULL DEFAULT 'Atendimento assistencial e gestão hospitalar',
    consent_at DATETIME NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_patient_creator FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_patient_name (name),
    INDEX idx_patient_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE encounters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT UNSIGNED NOT NULL,
    chief_complaint_enc TEXT NOT NULL,
    systolic SMALLINT UNSIGNED NOT NULL,
    diastolic SMALLINT UNSIGNED NOT NULL,
    temperature DECIMAL(4,1) NOT NULL,
    heart_rate SMALLINT UNSIGNED NOT NULL,
    spo2 TINYINT UNSIGNED NOT NULL,
    specialty_hint VARCHAR(100) NULL,
    status ENUM('aguardando_triagem','aguardando_medico','em_atendimento','medicacao','alta') NOT NULL DEFAULT 'aguardando_triagem',
    priority_color ENUM('vermelho','laranja','amarelo','verde','azul') NULL,
    priority_label VARCHAR(50) NULL,
    max_wait_minutes SMALLINT UNSIGNED NULL,
    triage_confirmed_by BIGINT UNSIGNED NULL,
    triage_confirmed_at DATETIME NULL,
    assigned_professional_id BIGINT UNSIGNED NULL,
    assigned_resource_id BIGINT UNSIGNED NULL,
    checkin_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    care_started_at DATETIME NULL,
    discharged_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_enc_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
    CONSTRAINT fk_enc_triage_user FOREIGN KEY (triage_confirmed_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_enc_prof FOREIGN KEY (assigned_professional_id) REFERENCES professionals(id) ON DELETE SET NULL,
    CONSTRAINT fk_enc_resource FOREIGN KEY (assigned_resource_id) REFERENCES care_resources(id) ON DELETE SET NULL,
    INDEX idx_enc_status_priority_wait (status, priority_color, checkin_at),
    INDEX idx_enc_prof_status (assigned_professional_id, status),
    INDEX idx_enc_resource_status (assigned_resource_id, status),
    INDEX idx_enc_checkin (checkin_at),
    INDEX idx_enc_discharged (discharged_at)
) ENGINE=InnoDB;

CREATE TABLE triage_assessments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    encounter_id BIGINT UNSIGNED NOT NULL,
    suggested_color ENUM('vermelho','laranja','amarelo','verde','azul') NOT NULL,
    confirmed_color ENUM('vermelho','laranja','amarelo','verde','azul') NOT NULL,
    nurse_user_id BIGINT UNSIGNED NOT NULL,
    override_reason VARCHAR(500) NULL,
    rules_json JSON NOT NULL,
    ai_suggestion_text TEXT NULL,
    ai_status ENUM('available','fallback','disabled','error') NOT NULL DEFAULT 'fallback',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_triage_enc FOREIGN KEY (encounter_id) REFERENCES encounters(id) ON DELETE CASCADE,
    CONSTRAINT fk_triage_nurse FOREIGN KEY (nurse_user_id) REFERENCES users(id),
    INDEX idx_triage_enc_created (encounter_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE clinical_outcomes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    encounter_id BIGINT UNSIGNED NOT NULL UNIQUE,
    diagnosis_cid VARCHAR(20) NOT NULL,
    clinical_notes_enc MEDIUMTEXT NOT NULL,
    prescription_enc MEDIUMTEXT NULL,
    attachment_path VARCHAR(255) NULL,
    attachment_original_name VARCHAR(255) NULL,
    attachment_mime VARCHAR(100) NULL,
    physician_user_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_outcome_enc FOREIGN KEY (encounter_id) REFERENCES encounters(id) ON DELETE CASCADE,
    CONSTRAINT fk_outcome_doc FOREIGN KEY (physician_user_id) REFERENCES users(id),
    INDEX idx_outcome_doc_created (physician_user_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE hygiene_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    care_resource_id BIGINT UNSIGNED NOT NULL,
    encounter_id BIGINT UNSIGNED NULL,
    started_at DATETIME NOT NULL,
    completed_at DATETIME NULL,
    completed_by BIGINT UNSIGNED NULL,
    notes VARCHAR(500) NULL,
    CONSTRAINT fk_hygiene_resource FOREIGN KEY (care_resource_id) REFERENCES care_resources(id),
    CONSTRAINT fk_hygiene_enc FOREIGN KEY (encounter_id) REFERENCES encounters(id) ON DELETE SET NULL,
    CONSTRAINT fk_hygiene_user FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_hygiene_open (completed_at, started_at)
) ENGINE=InnoDB;

CREATE TABLE alerts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    type ENUM('wait_time','hygiene','occupancy','maintenance','professional_expiry','clinical_risk') NOT NULL,
    severity ENUM('info','warning','critical') NOT NULL,
    message VARCHAR(600) NOT NULL,
    entity_type VARCHAR(60) NULL,
    entity_id BIGINT UNSIGNED NULL,
    fingerprint CHAR(64) NOT NULL,
    resolved_at DATETIME NULL,
    resolved_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_alert_resolver FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_openish_fingerprint_created (fingerprint, created_at),
    INDEX idx_alert_open_type (resolved_at, type),
    INDEX idx_alert_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE notification_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alert_id BIGINT UNSIGNED NOT NULL,
    channel ENUM('panel','email') NOT NULL,
    recipient VARCHAR(190) NULL,
    status ENUM('sent','logged','failed') NOT NULL,
    detail VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_alert FOREIGN KEY (alert_id) REFERENCES alerts(id) ON DELETE CASCADE,
    INDEX idx_notification_alert (alert_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(80) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id BIGINT UNSIGNED NULL,
    purpose VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NULL,
    metadata_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_user_created (user_id, created_at),
    INDEX idx_audit_entity_created (entity_type, entity_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE ai_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    module VARCHAR(60) NOT NULL,
    provider VARCHAR(40) NOT NULL,
    model VARCHAR(100) NULL,
    status ENUM('success','fallback','disabled','error') NOT NULL,
    latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
    prompt_hash CHAR(64) NULL,
    request_meta_json JSON NULL,
    response_excerpt VARCHAR(1000) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ai_module_created (module, created_at),
    INDEX idx_ai_status_created (status, created_at)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- DADOS DE DEMONSTRACAO
USE senn_med_ai;

INSERT INTO care_resources (code, sector, type, equipment_json, status, next_maintenance_date, notes) VALUES
('CONS-01','Pronto Atendimento A','consultorio',JSON_ARRAY('Oxímetro','Esfigmomanômetro'),'livre',DATE_ADD(CURDATE(), INTERVAL 60 DAY),'Consultório clínico'),
('CONS-02','Pronto Atendimento A','consultorio',JSON_ARRAY('Oxímetro','ECG portátil'),'livre',DATE_ADD(CURDATE(), INTERVAL 5 DAY),'Consultório de apoio'),
('OBS-01','Observação','observacao',JSON_ARRAY('Monitor multiparamétrico','Oxigênio'),'livre',DATE_ADD(CURDATE(), INTERVAL 45 DAY),'Leito de observação'),
('OBS-02','Observação','observacao',JSON_ARRAY('Monitor multiparamétrico','Oxigênio'),'higienizacao',DATE_ADD(CURDATE(), INTERVAL 40 DAY),'Em higienização de demonstração'),
('UTI-01','Unidade Crítica','uti',JSON_ARRAY('Ventilador','Monitor multiparamétrico','Bomba de infusão'),'livre',DATE_ADD(CURDATE(), INTERVAL 30 DAY),'Leito crítico'),
('ISO-01','Isolamento','isolamento',JSON_ARRAY('Pressão negativa','Oxigênio'),'livre',DATE_ADD(CURDATE(), INTERVAL 90 DAY),'Leito de isolamento');

UPDATE care_resources SET cleaning_started_at = DATE_SUB(NOW(), INTERVAL 50 MINUTE) WHERE code='OBS-02';

INSERT INTO professionals (name, registration_type, registration_number, registration_expires_at, specialty, contact, shift_label, availability_status, care_resource_id) VALUES
('Dra. Ana Ribeiro','CRM','CRM-SP-100001',DATE_ADD(CURDATE(), INTERVAL 365 DAY),'Clínica Geral','ana.ribeiro@sennmed.local','07:00-19:00','disponivel',1),
('Dr. Bruno Costa','CRM','CRM-SP-100002',DATE_ADD(CURDATE(), INTERVAL 20 DAY),'Cardiologia','bruno.costa@sennmed.local','07:00-19:00','disponivel',2),
('Enf. Camila Souza','COREN','COREN-SP-200001',DATE_ADD(CURDATE(), INTERVAL 300 DAY),'Triagem','camila.souza@sennmed.local','07:00-19:00','disponivel',NULL),
('Dra. Daniela Lima','CRM','CRM-SP-100003',DATE_ADD(CURDATE(), INTERVAL 500 DAY),'Pediatria','daniela.lima@sennmed.local','19:00-07:00','indisponivel',NULL);

INSERT INTO users (name,email,password_hash,role,professional_id,status) VALUES
('Administrador SENN','admin@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$WEhHekRCTEpzalozS0I1dg$bCEaqd+COPiwQYyzmKvCInyPwgYxxwDJHvdrEE91TPk','admin',NULL,'active'),
('Dra. Ana Ribeiro','medico@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$Lnh2M0F6VDBZdzhoMnVIeA$1mqdbMaJLuRon0Ug4jhIgx5H/UL6twuy3r3w2UK65cw','doctor',1,'active'),
('Enf. Camila Souza','enfermeiro@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$Lnh2M0F6VDBZdzhoMnVIeA$1mqdbMaJLuRon0Ug4jhIgx5H/UL6twuy3r3w2UK65cw','nurse',3,'active'),
('Recepção Central','recepcao@sennmed.local','$argon2id$v=19$m=65536,t=4,p=1$Lnh2M0F6VDBZdzhoMnVIeA$1mqdbMaJLuRon0Ug4jhIgx5H/UL6twuy3r3w2UK65cw','receptionist',NULL,'active');

INSERT INTO patients (medical_record_no,name,cpf_enc,cpf_hash,birth_date,gender,insurance,allergies_enc,comorbidities_enc,consent_given,consent_at,created_by) VALUES
('PR-2026-0001','Marcos Almeida','LRpWGq/BV/416zza1dMLjFQpEO5oNn7IjZhyXg0NfN2P/layESnRI9Mp','f358161d1ccfc3df09d9d379bfc4458f5994834db765166fd1202b3d0192a293','1978-04-12','M','SENN Saúde','L4uQbBIF+W1HQIrjLCiroEcms2+QYzTE/T1gPhkHfbJxohTX','1igKkyU6gD+IARKB3trY6W+UdCJnUwPycslyqvBv53NUw9ZcfshMeQ==',1,NOW(),4),
('PR-2026-0002','Juliana Martins','dnHlLWKTtSLTvuUKUBzmpN222bRJq2LW3ts9Drz5ox/ej8BOl7AP7Xyx','716035db87c32a05f9b60f41a7fbc70c4c57fb32448f90553fec4bc5a9cc8ac8','1991-09-21','F','Particular','C9gu7Vyi2QksnZMyTX3AExEQLQoy9pzrvu0kP5+nRSokwSjqP+RtfxsULabMuHLPB0UwNfA=','WD0Pap3fYtiJH5H4+Nzh/5f38+OEoPx2L8ncNmQimHNIdWNtg79rrZgjIg==',1,NOW(),4),
('PR-2026-0003','Rafael Nunes','DuPLZe0JAI5ASp+8bQd0gnH9sAUb8vOGZzuje2hxCrg7eZayK+Y3g5oV','b30c358573fbdb64626c9ffa3012c9bede3007af7aa8d63c700910b60a865791','2004-02-03','M','SENN Saúde','U2JV8Pft7lTLNI0hVBWKA2kGj76qFMXKCebEI+LNc3yDP7Mb5ag=','u/3lsVALrPJ67LZBB8a9Zmjb9TpEtQo0SLph545u6xM=',1,NOW(),4);

INSERT INTO encounters (patient_id,chief_complaint_enc,systolic,diastolic,temperature,heart_rate,spo2,status,checkin_at) VALUES
(1,'LL6CeI/HypB5r3rPK10JFbPQzK1b7CHinuVDelt/WBOGuGYJ7D0yARBfJXToYWoQggS2sfMm',92,61,37.4,128,92,'aguardando_triagem',DATE_SUB(NOW(), INTERVAL 8 MINUTE)),
(2,'XdhyPF5yWvT0RcAFNhGrwYnxajRL9DTNaKpl8imxiZQpEqEKvueH6z3jf4YEKg==',118,77,39.2,108,95,'aguardando_triagem',DATE_SUB(NOW(), INTERVAL 25 MINUTE)),
(3,'kzl3Esj8yQ16t+HGlQvjhgnOnkreblsEvvb2Sk8NMbGpNVwG2+dSCmxF2T0fQI6VCKddspVYnYGWDmbttg==',122,80,36.7,78,98,'aguardando_triagem',DATE_SUB(NOW(), INTERVAL 12 MINUTE));

-- Histórico agregado realista para previsão e dashboard. Dados clínicos livres não são necessários nesses registros.
INSERT INTO patients (medical_record_no,name,birth_date,gender,insurance,consent_given,consent_at,created_by)
SELECT CONCAT('HIST-', LPAD(n,4,'0')), CONCAT('Paciente Histórico ', n), DATE_SUB(CURDATE(), INTERVAL (20+n) YEAR), IF(MOD(n,2)=0,'F','M'), 'SENN Saúde', 1, DATE_SUB(NOW(), INTERVAL n DAY), 4
FROM (
  SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10 UNION
  SELECT 11 UNION SELECT 12 UNION SELECT 13 UNION SELECT 14 UNION SELECT 15 UNION SELECT 16 UNION SELECT 17 UNION SELECT 18 UNION SELECT 19 UNION SELECT 20 UNION
  SELECT 21 UNION SELECT 22 UNION SELECT 23 UNION SELECT 24 UNION SELECT 25 UNION SELECT 26 UNION SELECT 27 UNION SELECT 28 UNION SELECT 29 UNION SELECT 30
) seq;

INSERT INTO encounters (patient_id,chief_complaint_enc,systolic,diastolic,temperature,heart_rate,spo2,specialty_hint,status,priority_color,priority_label,max_wait_minutes,checkin_at,care_started_at,discharged_at)
SELECT p.id, '', 120,80,36.8,80,98,
       CASE MOD(p.id,4) WHEN 0 THEN 'Clínica Geral' WHEN 1 THEN 'Cardiologia' WHEN 2 THEN 'Pediatria' ELSE 'Ortopedia' END,
       'alta',
       CASE MOD(p.id,5) WHEN 0 THEN 'vermelho' WHEN 1 THEN 'laranja' WHEN 2 THEN 'amarelo' WHEN 3 THEN 'verde' ELSE 'azul' END,
       CASE MOD(p.id,5) WHEN 0 THEN 'Emergência' WHEN 1 THEN 'Muito Urgente' WHEN 2 THEN 'Urgente' WHEN 3 THEN 'Pouco Urgente' ELSE 'Não Urgente' END,
       CASE MOD(p.id,5) WHEN 0 THEN 0 WHEN 1 THEN 10 WHEN 2 THEN 60 WHEN 3 THEN 120 ELSE 240 END,
       DATE_SUB(NOW(), INTERVAL (p.id-3) DAY),
       DATE_ADD(DATE_SUB(NOW(), INTERVAL (p.id-3) DAY), INTERVAL (5 + MOD(p.id,30)) MINUTE),
       DATE_ADD(DATE_SUB(NOW(), INTERVAL (p.id-3) DAY), INTERVAL (60 + MOD(p.id,240)) MINUTE)
FROM patients p WHERE p.medical_record_no LIKE 'HIST-%';

INSERT INTO hygiene_events (care_resource_id, started_at) SELECT id, cleaning_started_at FROM care_resources WHERE status='higienizacao';
