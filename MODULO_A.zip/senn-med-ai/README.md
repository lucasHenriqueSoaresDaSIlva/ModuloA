# SENN MED-AI — versão pronta para XAMPP

> **Atalho para apresentação no XAMPP:** esta cópia já inclui `.env` configurado para o XAMPP padrão (`root` sem senha) e roteamento compatível com `http://localhost/senn-med-ai/`. Basta importar `database/schema.sql` e `database/seed.sql`, ligar Apache/MySQL e abrir a URL.

# SENN MED-AI — Smart Care

Plataforma web educacional para o **SENAI Dev Experience 2026 — Módulo A**, cobrindo gestão hospitalar, triagem, alocação, leitos, tempo real, indicadores e módulos de IA.

> **Importante:** este projeto é um protótipo acadêmico. A árvore de triagem é uma aproximação demonstrativa baseada nos tempos e classes fornecidos pelo caderno da prova; não é uma implementação certificada do Manchester Triage System e não deve ser utilizada para atendimento clínico real sem validação institucional, regulatória e médica adequada.

## Recursos implementados

- Quatro perfis: administrador, médico, enfermeiro de triagem e recepcionista.
- Cadastro de usuários, profissionais, leitos/consultórios e pacientes.
- Importação CSV de fichas com validação.
- Triagem híbrida: regras determinísticas + complemento opcional de IA + confirmação/override do enfermeiro.
- Prioridades: Vermelho 0 min, Laranja 10 min, Amarelo 60 min, Verde 120 min, Azul 240 min.
- Alocação automática por gravidade, tempo de espera, especialidade, disponibilidade e tipo de recurso.
- Mapa de ocupação em CSS Grid com SSE e fallback polling.
- Desfecho clínico com CID, conduta, anexo e ciclo de higienização.
- Previsão local de demanda 7/30 dias, risco de estouro de tempo, análise inteligente e chatbot.
- Dashboard, filtros e exportações PDF/Excel.
- Alertas com painel, tentativa de e-mail, resolução e logs.
- Segurança, auditoria, criptografia AES-256-GCM e práticas LGPD.
- Backup automatizado e manual por perfil.
- RF14 bônus: fluxo explícito de higienização e liberação de recurso.

## Pré-requisitos

- PHP 8.1+ (recomendado 8.2+)
- Extensões: `pdo`, `pdo_mysql`, `openssl`, `fileinfo`, `json`; recomendadas `curl` e `mbstring`
- MySQL 8+
- `mysqldump` para o script de backup
- Acesso à internet apenas se usar IA externa

## Rodar em 3 comandos

Linux/macOS:

```bash
cp .env.example .env
mysql -u root -p < database/schema.sql && mysql -u root -p senn_med_ai < database/seed.sql
php -S localhost:8000 -t public public/router.php
```

Abra `http://localhost:8000`.

No Windows PowerShell, o equivalente do primeiro comando é `Copy-Item .env.example .env`. Para importar SQL, use o cliente MySQL disponível no PATH.

## Configuração

Edite `.env`:

```dotenv
APP_ENV=development
APP_DEBUG=true
APP_URL=http://localhost:8000
APP_TIMEZONE=America/Sao_Paulo
SESSION_NAME=senn_med_ai_session
SESSION_SECURE=false
APP_ENCRYPTION_KEY=base64:troque-por-32-bytes-em-base64

DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=senn_med_ai
DB_USERNAME=root
DB_PASSWORD=

AI_PROVIDER=openai
AI_API_KEY=
AI_MODEL=gpt-4.1-mini
AI_TIMEOUT_SECONDS=6
AI_CLINICAL_CONTEXT_ENABLED=true

MAIL_ENABLED=false
MAIL_FROM=no-reply@senn-med-ai.local
ALERT_EMAIL=gestao@senn-med-ai.local
UPLOAD_MAX_BYTES=5242880
HYGIENE_ALERT_MINUTES=45
PROFESSIONAL_EXPIRY_ALERT_DAYS=30
MAINTENANCE_ALERT_DAYS=7
```

Nunca comite `.env`. A `.gitignore` já o exclui.

### Chave de criptografia

Para produção, gere uma chave exclusiva de 32 bytes e mantenha-a em cofre de segredos. Exemplo:

```bash
php -r "echo 'base64:'.base64_encode(random_bytes(32)).PHP_EOL;"
```

Se trocar a chave depois de gravar dados, os campos já criptografados não poderão ser lidos sem a chave anterior.

## Usuários de teste

| Perfil | Login | Senha |
|---|---|---|
| Administrador | `admin@sennmed.local` | `Admin@2026!` |
| Médico | `medico@sennmed.local` ou `CRM-SP-100001` | `Senai@2026!` |
| Enfermeiro | `enfermeiro@sennmed.local` ou `COREN-SP-200001` | `Senai@2026!` |
| Recepcionista | `recepcao@sennmed.local` | `Senai@2026!` |

Troque todas as senhas em qualquer ambiente fora da demonstração.

## Banco de dados

- `database/schema.sql`: cria banco, tabelas, chaves, índices e constraints.
- `database/seed.sql`: profissionais, usuários, recursos, pacientes demonstrativos e histórico para dashboard/previsão.

Dados textuais clínicos do seed são criptografados usando a chave de desenvolvimento do `.env.example`. Isso serve apenas para a demonstração.

## Segurança e LGPD

- `password_hash(..., PASSWORD_ARGON2ID)` e `password_verify`.
- Sessão com `HttpOnly`, `SameSite=Strict` e regeneração de ID no login.
- PDO com prepared statements e emulação desativada.
- CSRF em todas as ações mutáveis.
- Escape de saída com `htmlspecialchars`.
- Upload por MIME real (`finfo`), tamanho, extensão controlada e nome aleatório fora de `public/`.
- AES-256-GCM para CPF e campos clínicos textuais sensíveis.
- Hash determinístico do CPF para detectar duplicidade sem descriptografar.
- Auditoria com usuário, ação, entidade, finalidade, IP e data/hora.
- Relatórios gerenciais são agregados e não exibem identificadores diretos.
- Toda autorização sensível é revalidada no servidor.

## Triagem

### Motor determinístico

`app/Services/TriageService.php` analisa, no conjunto demonstrativo:

- pressão sistólica;
- temperatura;
- frequência cardíaca;
- SpO2;
- termos de alerta na queixa;
- comorbidades relevantes.

A árvore gera uma **sugestão**, nunca a decisão final. O enfermeiro deve confirmar ou selecionar outra prioridade; qualquer override exige justificativa.

### Alocação

`AllocationService` calcula um score:

```text
score = peso_da_gravidade * 100000 + minutos_de_espera
```

Pesos: Vermelho 5, Laranja 4, Amarelo 3, Verde 2, Azul 1.

Depois procura:

1. médico disponível da especialidade sugerida;
2. clínica geral como fallback;
3. recurso livre compatível com gravidade;
4. se nada estiver disponível, mantém paciente na fila sem bloquear a triagem.

Vermelho/Laranja priorizam UTI/Observação; demais priorizam Consultório/Observação.

## IA

### Provedores

Defina `AI_PROVIDER=openai` ou `AI_PROVIDER=gemini`.

- OpenAI: chamada server-side a `POST /v1/chat/completions`.
- Gemini: chamada server-side a `models/{model}:generateContent`.
- Chave apenas no `.env`, nunca no navegador.
- Timeout por `AI_TIMEOUT_SECONDS`.
- Falha, ausência de chave, erro HTTP ou cURL indisponível retorna fallback sem interromper cadastro, triagem, alocação ou dashboard.

### Prompts completos

**Triagem complementar**

```text
SYSTEM:
Você é um módulo de apoio operacional de triagem. Nunca substitua o protocolo institucional nem o profissional habilitado. Não diagnostique e não emita prescrição.

USER:
Contexto clínico pseudonimizado, sem nome, CPF ou prontuário.
PA: {sistolica}/{diastolica} mmHg; temperatura: {temperatura} C; FC: {fc} bpm; SpO2: {spo2}%.
Queixa: {queixa_limitada}
Comorbidades: {comorbidades_limitadas}
O motor determinístico sugeriu {cor}. Explique em até 4 frases fatores de atenção e dados que o enfermeiro deve confirmar. Não altere a prioridade nem dê diagnóstico.
```

**Previsão de demanda**

```text
SYSTEM:
Você analisa apenas dados hospitalares agregados e oferece recomendações operacionais, sem aconselhamento clínico individual.

USER:
Previsão estatística local agregada para {7|30} dias: {serie_json}. Resuma em até 5 frases riscos operacionais, sazonalidade aparente e ações de capacidade. Não trate de pacientes individuais.
```

**Risco de agravamento/estouro de tempo**

```text
SYSTEM:
Você recebe apenas referências pseudonimizadas e métricas operacionais. Sugira ações de fluxo, nunca diagnóstico ou conduta médica.

USER:
Casos sinalizados: {top_risk_json}. Resuma prioridades operacionais em até 6 linhas.
```

**Análise operacional**

```text
SYSTEM:
Você é um analista operacional hospitalar. Trabalhe apenas com dados agregados. Não forneça diagnóstico nem decisão clínica individual.

USER:
Dados agregados: {dados_json}. Identifique gargalos, turnos de sobrecarga e até 5 recomendações objetivas de recursos.
```

**SENN MED-AI Helper**

```text
SYSTEM:
Você é o SENN MED-AI Helper. Responda sobre uso do sistema, protocolo configurado e indicadores operacionais. Não invente dados, não diagnostique e não prescreva. Sempre lembre que saídas clínicas são suporte à decisão profissional.

USER:
Contexto operacional atual: {contexto_agregado_json}
Pergunta do usuário: {pergunta}
```

### Fallback RNF06

Quando IA não funciona, o sistema mostra **“IA indisponível – modo manual”**. Cadastro de pacientes, classificação manual, regras locais, alocação, monitoramento, alertas e previsão baseline continuam operando.

## Previsão local sem API

`ForecastService` agrupa histórico por dia da semana e calcula média sazonal para projetar os próximos 7/30 dias. A API apenas gera interpretação textual opcional.

## Tempo real

- `/events/monitoring`: SSE, snapshot a cada ~3 segundos.
- `/api/monitoring-snapshot`: endpoint de fallback.
- `monitoring.js`: se `EventSource` falha, inicia polling a cada 5 segundos.

## Alertas

`AlertService` verifica:

- espera acima do limite Manchester;
- higienização acima de `HYGIENE_ALERT_MINUTES`;
- ocupação acima de 90%;
- manutenção próxima;
- CRM/COREN próximo do vencimento.

Execução manual:

```bash
php bin/scan_alerts.php
```

Cron sugerido a cada 5 minutos:

```cron
*/5 * * * * /usr/bin/php /caminho/senn-med-ai/bin/scan_alerts.php >> /caminho/senn-med-ai/storage/logs/alerts.log 2>&1
```

## Backup

```bash
./bin/backup.sh
```

Veja `docs/BACKUP_RESTORE.md`.

## Testes

```bash
php tests/run.php
find app config public resources/views -name '*.php' -print0 | xargs -0 -n1 php -l
php bin/healthcheck.php
```

O teste unitário leve não exige banco. O `healthcheck` testa a conexão MySQL e extensões.

## Estrutura

Veja `docs/ARQUITETURA.md` e `docs/ANALISE_E_RASTREABILIDADE.md`.

## CSV

Cabeçalho exato:

```csv
nome,cpf,nascimento,sexo,convenio,queixa,pressao_sistolica,pressao_diastolica,temperatura,fc,spo2,alergias,comorbidades,consentimento
```

Exemplo:

```csv
Maria Silva,12345678901,1988-05-10,F,SENN Saúde,Febre e tosse,118,76,38.7,104,96,Nenhuma,Asma,sim
```

## Git e entrega

O repositório contém histórico local de commits semânticos. Veja `docs/COMMITS.md`.

Para publicar:

```bash
git remote add origin SEU_REPOSITORIO.git
git push -u origin main
```

Depois adicione como colaboradores do repositório:

- `Cardoso30S`
- `fiorezewesley`
- `Greggori`

Texto do PDF e instrução de ZIP: `docs/ENTREGA.md`.

## Checklist

Ver `docs/CHECKLIST_FINAL.md`.


## Interface profissional
Esta distribuição inclui redesign completo responsivo da interface, navegação lateral, login hospitalar, dashboard aprimorado e SENN MED-AI Helper redesenhado.
