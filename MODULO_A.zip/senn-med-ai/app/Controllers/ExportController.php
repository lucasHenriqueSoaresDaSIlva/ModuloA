<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Validator; use App\Repositories\AnalyticsRepository; use App\Services\PdfReportService;

final class ExportController
{
    public function export(): void
    {
        Auth::requireRole(['admin','doctor','nurse']);$format=strtolower((string)($_GET['format']??'pdf'));$from=(string)($_GET['from']??date('Y-m-d',strtotime('-30 days')));$to=(string)($_GET['to']??date('Y-m-d'));if(!Validator::date($from)||!Validator::date($to))exit('Período inválido.');
        $m=(new AnalyticsRepository())->metrics($from,$to);$s=$m['summary'];
        if($format==='xls'){$filename='relatorio_senn_med_ai_'.date('Ymd_His').'.xls';header('Content-Type: application/vnd.ms-excel; charset=UTF-8');header('Content-Disposition: attachment; filename="'.$filename.'"');echo "\xEF\xBB\xBF";echo '<table border="1"><tr><th>Métrica</th><th>Valor</th></tr>';foreach(['Total'=>$s['total']??0,'TME (min)'=>$s['avg_wait']??0,'Permanência média (min)'=>$s['avg_stay']??0,'Dentro do protocolo (%)'=>$s['within_protocol']??0,'Ocupação (%)'=>$s['occupancy']??0] as $k=>$v)echo '<tr><td>'.htmlspecialchars($k).'</td><td>'.htmlspecialchars((string)$v).'</td></tr>';echo '</table>';exit;}
        $lines=["Período: {$from} a {$to}","Total de atendimentos: ".($s['total']??0),"Tempo médio de espera: ".($s['avg_wait']??0).' min',"Tempo médio de permanência: ".($s['avg_stay']??0).' min',"Atendidos dentro do protocolo: ".($s['within_protocol']??0).'%',"Ocupação atual: ".($s['occupancy']??0).'%','', 'Relatório contém apenas métricas agregadas e não identifica pacientes.'];
        $pdf=(new PdfReportService())->build('SENN MED-AI - Relatório Gerencial',$lines);header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="relatorio_senn_med_ai_'.date('Ymd_His').'.pdf"');header('Content-Length: '.strlen($pdf));echo $pdf;exit;
    }
}
