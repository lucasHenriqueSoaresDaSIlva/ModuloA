<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Validator; use App\Core\View; use App\Repositories\AlertRepository; use App\Repositories\AnalyticsRepository; use App\Services\AlertService;

final class DashboardController
{
    public function index(): void
    {
        Auth::requireLogin();$from=(string)($_GET['from']??date('Y-m-d',strtotime('-30 days')));$to=(string)($_GET['to']??date('Y-m-d'));if(!Validator::date($from)||!Validator::date($to)){$from=date('Y-m-d',strtotime('-30 days'));$to=date('Y-m-d');}
        try{(new AlertService())->scan();}catch(\Throwable){}$metrics=(new AnalyticsRepository())->metrics($from,$to);$alerts=(new AlertRepository())->open();
        View::render('dashboard/index',['title'=>'Dashboard','metrics'=>$metrics,'alerts'=>array_slice($alerts,0,5)]);
    }
}
