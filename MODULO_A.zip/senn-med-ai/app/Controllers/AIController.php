<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Response; use App\Core\Validator; use App\Core\View;
use App\Services\AssistantService; use App\Services\ForecastService; use App\Services\OperationalAnalysisService; use App\Services\RiskService;

final class AIController
{
    public function forecast(): void {Auth::requireRole(['admin','doctor','nurse']);$days=(int)($_GET['days']??7);View::render('ai/forecast',['title'=>'Previsão de demanda','forecast'=>(new ForecastService())->forecast($days),'days'=>in_array($days,[7,30],true)?$days:7]);}
    public function risk(): void {Auth::requireRole(['admin','doctor','nurse']);View::render('ai/risk',['title'=>'Risco e estouro de tempo','risk'=>(new RiskService())->analyze()]);}
    public function analysis(): void {Auth::requireRole(['admin','doctor','nurse']);$days=max(7,min(90,(int)($_GET['days']??30)));View::render('ai/analysis',['title'=>'Análise inteligente','analysis'=>(new OperationalAnalysisService())->analyze($days),'days'=>$days]);}
    public function assistant(): void
    {
        Auth::requireLogin();$token=$_SERVER['HTTP_X_CSRF_TOKEN']??($_POST['_csrf']??null);Csrf::requireValid($token);$question=Validator::cleanText($_POST['question']??'',500);if($question==='')Response::json(['error'=>'Pergunta vazia.'],422);
        Response::json((new AssistantService())->answer($question));
    }
}
