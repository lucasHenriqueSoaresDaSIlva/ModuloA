<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Core\Response;
use App\Core\Validator;
use App\Core\View;
use App\Repositories\AuditRepository;
use App\Repositories\UserRepository;

final class AuthController
{
    public function show(): void
    {
        if (Auth::check()) Response::redirect('/dashboard');
        View::render('auth/login', ['title'=>'Entrar']);
    }

    public function login(): void
    {
        Csrf::requireValid($_POST['_csrf'] ?? null);
        $identifier=Validator::cleanText($_POST['identifier']??'',190);
        $password=(string)($_POST['password']??'');
        $role=(string)($_POST['role']??'');
        if(!in_array($role,['admin','doctor','nurse','receptionist'],true) || $identifier==='' || $password===''){
            Flash::set('error','Preencha identificador, senha e perfil.'); Response::redirect('/login');
        }
        $repo=new UserRepository(); $user=$repo->findForLogin($identifier,$role);
        if(!$user || !password_verify($password,$user['password_hash'])){
            usleep(250000); Flash::set('error','Credenciais inválidas.'); Response::redirect('/login');
        }
        if(password_needs_rehash($user['password_hash'],PASSWORD_ARGON2ID)){
            // Rehash é opcional e não deve bloquear o login; atualização poderá ser feita por rotina administrativa.
        }
        Auth::login($user); $repo->touchLogin((int)$user['id']);
        (new AuditRepository())->log('login','user',(int)$user['id'],'Autenticação no sistema',['role'=>$role]);
        Response::redirect('/dashboard');
    }

    public function logout(): void
    {
        Auth::requireLogin(); Csrf::requireValid($_POST['_csrf']??null);
        (new AuditRepository())->log('logout','user',Auth::id(),'Encerramento de sessão');
        Auth::logout(); Response::redirect('/login');
    }
}
