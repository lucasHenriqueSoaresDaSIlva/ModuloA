<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Flash; use App\Core\Response; use App\Core\View; use App\Repositories\AlertRepository; use App\Repositories\AuditRepository; use App\Services\AlertService;

final class AlertsController
{
    public function index(): void {Auth::requireRole(['admin','doctor','nurse']);View::render('alerts/index',['title'=>'Alertas','alerts'=>(new AlertRepository())->open()]);}
    public function scan(): void {Auth::requireRole(['admin','nurse']);Csrf::requireValid($_POST['_csrf']??null);$n=(new AlertService())->scan();Flash::set('success',"Varredura concluída: {$n} novo(s) alerta(s).");Response::redirect('/alerts');}
    public function resolve(string $id): void {Auth::requireRole(['admin','doctor','nurse']);Csrf::requireValid($_POST['_csrf']??null);$aid=(int)$id;(new AlertRepository())->resolve($aid,(int)Auth::id());(new AuditRepository())->log('resolve','alert',$aid,'Tratamento de alerta operacional');Flash::set('success','Alerta marcado como resolvido.');Response::redirect('/alerts');}
}
