<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Flash; use App\Core\Response; use App\Core\Validator; use App\Core\View;
use App\Repositories\AuditRepository; use App\Repositories\PatientRepository; use App\Repositories\TriageRepository; use App\Services\AllocationService; use App\Services\TriageService;

final class TriageController
{
    public function queue(): void {Auth::requireRole(['admin','nurse','doctor']);View::render('triage/queue',['title'=>'Fila de triagem','queue'=>(new TriageRepository())->queue()]);}
    public function show(string $id): void
    {
        Auth::requireRole(['admin','nurse','doctor']);$enc=(new PatientRepository())->findEncounter((int)$id);if(!$enc){http_response_code(404);View::render('errors/404',['title'=>'Atendimento não encontrado']);return;}
        $suggestion=(new TriageService())->suggest($enc);$allocation=(new AllocationService())->allocate($enc,$suggestion['suggested_color']);
        (new AuditRepository())->log('view','encounter',(int)$id,'Triagem e suporte à decisão');View::render('triage/show',['title'=>'Triagem','enc'=>$enc,'suggestion'=>$suggestion,'allocation'=>$allocation,'priorities'=>TriageService::PRIORITIES]);
    }
    public function confirm(string $id): void
    {
        Auth::requireRole(['admin','nurse']);Csrf::requireValid($_POST['_csrf']??null);$eid=(int)$id;$enc=(new PatientRepository())->findEncounter($eid);if(!$enc){Flash::set('error','Atendimento não encontrado.');Response::redirect('/triage');}
        $service=new TriageService();$s=$service->suggest($enc);$confirmed=(string)($_POST['confirmed_color']??$s['suggested_color']);
        if(!isset(TriageService::PRIORITIES[$confirmed])){Flash::set('error','Classificação inválida.');Response::redirect('/triage/'.$eid);}
        $override=Validator::cleanText($_POST['override_reason']??'',500);if($confirmed!==$s['suggested_color']&&$override===''){Flash::set('error','Informe a justificativa ao alterar a sugestão.');Response::redirect('/triage/'.$eid);}
        $allocation=(new AllocationService())->allocate($enc,$confirmed);$assessment=['suggested_color'=>$s['suggested_color'],'confirmed_color'=>$confirmed,'override_reason'=>$override,'rules'=>$s['rules'],'ai_text'=>$s['ai_text'],'ai_status'=>$s['ai_status'],'priority_meta'=>$service->priorityMeta($confirmed)];
        (new TriageRepository())->saveAssessment($eid,(int)Auth::id(),$assessment,$allocation);(new AuditRepository())->log('triage_confirm','encounter',$eid,'Classificação de risco pelo profissional habilitado',['suggested'=>$s['suggested_color'],'confirmed'=>$confirmed,'override'=>$confirmed!==$s['suggested_color']]);
        Flash::set('success','Triagem confirmada e alocação processada.');Response::redirect('/monitoring');
    }
}
