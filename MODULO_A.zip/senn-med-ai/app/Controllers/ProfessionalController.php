<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Flash; use App\Core\Response; use App\Core\Validator; use App\Core\View;
use App\Repositories\AuditRepository; use App\Repositories\CareResourceRepository; use App\Repositories\ProfessionalRepository;

final class ProfessionalController
{
    public function index(): void
    {
        Auth::requireRole('admin'); View::render('professionals/index',['title'=>'Profissionais','professionals'=>(new ProfessionalRepository())->all(),'resources'=>(new CareResourceRepository())->all()]);
    }
    public function store(): void
    {
        Auth::requireRole('admin'); Csrf::requireValid($_POST['_csrf']??null);
        $name=Validator::cleanText($_POST['name']??'',150);$type=(string)($_POST['registration_type']??'');$number=Validator::cleanText($_POST['registration_number']??'',40);$expiry=(string)($_POST['registration_expires_at']??'');
        $specialty=Validator::cleanText($_POST['specialty']??'',100);$shift=Validator::cleanText($_POST['shift_label']??'',100);$availability=(string)($_POST['availability_status']??'disponivel');
        if($name===''||!in_array($type,['CRM','COREN'],true)||$number===''||!Validator::date($expiry)||strtotime($expiry)<strtotime(date('Y-m-d'))||$specialty===''||$shift===''||!in_array($availability,['disponivel','ocupado','indisponivel'],true)){
            Flash::set('error','Dados profissionais inválidos. A validade deve ser atual ou futura.');Response::redirect('/professionals');
        }
        try{$id=(new ProfessionalRepository())->create(['name'=>$name,'registration_type'=>$type,'registration_number'=>$number,'registration_expires_at'=>$expiry,'specialty'=>$specialty,'contact'=>Validator::cleanText($_POST['contact']??'',150)?:null,'shift_label'=>$shift,'availability_status'=>$availability,'care_resource_id'=>($_POST['care_resource_id']??'')!==''?(int)$_POST['care_resource_id']:null]);(new AuditRepository())->log('create','professional',$id,'Gestão do corpo clínico');Flash::set('success','Profissional cadastrado.');}
        catch(\Throwable $e){Flash::set('error','Falha ao cadastrar. Verifique se o CRM/COREN já existe.');}
        Response::redirect('/professionals');
    }
}
