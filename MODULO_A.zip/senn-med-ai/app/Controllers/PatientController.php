<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Encryption; use App\Core\Flash; use App\Core\Response; use App\Core\Validator; use App\Core\View;
use App\Repositories\AuditRepository; use App\Repositories\PatientRepository; use App\Services\CsvImportService;

final class PatientController
{
    public function index(): void
    {
        Auth::requireRole(['admin','receptionist','nurse','doctor']);$page=max(1,(int)($_GET['page']??1));$search=Validator::cleanText($_GET['q']??'',100);
        $data=(new PatientRepository())->paginate($page,20,$search);View::render('patients/index',['title'=>'Pacientes','data'=>$data,'search'=>$search]);
    }
    public function create(): void
    {
        Auth::requireRole(['admin','receptionist','nurse']);View::render('patients/create',['title'=>'Nova ficha']);
    }
    public function store(): void
    {
        Auth::requireRole(['admin','receptionist','nurse']);Csrf::requireValid($_POST['_csrf']??null);$repo=new PatientRepository();
        try{
            $d=[
                'nome'=>$_POST['name']??'','cpf'=>$_POST['cpf']??'','nascimento'=>$_POST['birth_date']??'','sexo'=>$_POST['gender']??'N','convenio'=>$_POST['insurance']??'',
                'queixa'=>$_POST['chief_complaint']??'','pressao_sistolica'=>$_POST['systolic']??'','pressao_diastolica'=>$_POST['diastolic']??'','temperatura'=>$_POST['temperature']??'',
                'fc'=>$_POST['heart_rate']??'','spo2'=>$_POST['spo2']??'','alergias'=>$_POST['allergies']??'','comorbidades'=>$_POST['comorbidities']??'','consentimento'=>isset($_POST['consent'])?'sim':'nao'
            ];
            $payload=(new CsvImportService())->validateAndBuild($d,$repo);$eid=$repo->createPatientAndEncounter($payload['patient'],$payload['encounter']);
            (new AuditRepository())->log('create','encounter',$eid,'Acolhimento e registro assistencial',['medical_record_no'=>$payload['patient']['medical_record_no']]);Flash::set('success','Ficha criada e adicionada à fila de triagem.');Response::redirect('/triage/'.$eid);
        }catch(\Throwable $e){Flash::set('error',$e->getMessage());Response::redirect('/patients/new');}
    }
    public function importForm(): void {Auth::requireRole(['admin','receptionist','nurse']);View::render('patients/import',['title'=>'Importar CSV']);}
    public function importCsv(): void
    {
        Auth::requireRole(['admin','receptionist','nurse']);Csrf::requireValid($_POST['_csrf']??null);$file=$_FILES['csv']??null;
        if(!$file||($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||($file['size']??0)>2097152){Flash::set('error','Envie um CSV válido de até 2 MB.');Response::redirect('/patients/import');}
        $mime=(new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);if(!in_array($mime,['text/plain','text/csv','application/csv','application/vnd.ms-excel'],true)){Flash::set('error','Tipo de arquivo inválido.');Response::redirect('/patients/import');}
        try{$res=(new CsvImportService())->import($file['tmp_name']);(new AuditRepository())->log('import','patient',null,'Importação de fichas CSV',['imported'=>$res['imported'],'errors'=>count($res['errors'])]);
            $_SESSION['import_result']=$res;Flash::set($res['errors']?'warning':'success',"Importação concluída: {$res['imported']} registro(s) inserido(s).");}
        catch(\Throwable $e){Flash::set('error',$e->getMessage());}
        Response::redirect('/patients/import');
    }
}
