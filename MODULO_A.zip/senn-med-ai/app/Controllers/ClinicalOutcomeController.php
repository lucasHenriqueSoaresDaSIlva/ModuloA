<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Encryption; use App\Core\Flash; use App\Core\Response; use App\Core\Validator; use App\Core\View;
use App\Repositories\AuditRepository; use App\Repositories\ClinicalOutcomeRepository; use App\Repositories\PatientRepository; use App\Services\UploadService;

final class ClinicalOutcomeController
{
    public function show(string $id): void
    {
        Auth::requireRole(['admin','doctor']);$enc=(new PatientRepository())->findEncounter((int)$id);if(!$enc){http_response_code(404);View::render('errors/404',['title'=>'Atendimento não encontrado']);return;}
        (new AuditRepository())->log('view','encounter',(int)$id,'Acesso ao prontuário para desfecho');View::render('clinical/show',['title'=>'Desfecho clínico','enc'=>$enc]);
    }
    public function store(string $id): void
    {
        Auth::requireRole(['admin','doctor']);Csrf::requireValid($_POST['_csrf']??null);$eid=(int)$id;
        $cid=strtoupper(Validator::cleanText($_POST['diagnosis_cid']??'',20));$notes=Validator::cleanText($_POST['clinical_notes']??'',5000);$prescription=Validator::cleanText($_POST['prescription']??'',5000);
        if($cid===''||$notes===''){Flash::set('error','CID e evolução/conduta são obrigatórios.');Response::redirect('/clinical/'.$eid);}
        try{$up=(new UploadService())->store($_FILES['attachment']??null);$rid=(new ClinicalOutcomeRepository())->save($eid,(int)Auth::id(),['diagnosis_cid'=>$cid,'clinical_notes_enc'=>Encryption::encrypt($notes),'prescription_enc'=>Encryption::encrypt($prescription),'attachment_path'=>$up['path'],'attachment_original_name'=>$up['original_name'],'attachment_mime'=>$up['mime']]);
            (new AuditRepository())->log('discharge','encounter',$eid,'Registro de desfecho e alta',['resource_to_hygiene'=>$rid]);Flash::set('success','Desfecho registrado. O recurso foi encaminhado para higienização.');Response::redirect('/hygiene');}
        catch(\Throwable $e){Flash::set('error',$e->getMessage());Response::redirect('/clinical/'.$eid);}
    }
}
