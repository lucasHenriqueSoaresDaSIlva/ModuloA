<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Flash; use App\Core\Response; use App\Core\Validator; use App\Core\View; use App\Repositories\AuditRepository; use App\Repositories\CareResourceRepository;

final class HygieneController
{
    public function index(): void {Auth::requireRole(['admin','nurse','receptionist']);View::render('hygiene/index',['title'=>'Higienização','items'=>(new CareResourceRepository())->cleaning()]);}
    public function complete(string $id): void {Auth::requireRole(['admin','nurse','receptionist']);Csrf::requireValid($_POST['_csrf']??null);$hid=(int)$id;(new CareResourceRepository())->completeCleaning($hid,(int)Auth::id(),Validator::cleanText($_POST['notes']??'',500));(new AuditRepository())->log('complete','hygiene_event',$hid,'Liberação de leito após higienização');Flash::set('success','Higienização concluída. Recurso liberado.');Response::redirect('/hygiene');}
}
