<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Flash; use App\Core\Response; use App\Core\View; use App\Core\Database; use App\Repositories\AuditRepository; use App\Repositories\MonitoringRepository; use App\Services\AlertService;

final class MonitoringController
{
    public function index(): void
    {
        Auth::requireLogin(); try{(new AlertService())->scan();}catch(\Throwable){} $snapshot=(new MonitoringRepository())->snapshot();
        View::render('monitoring/index',['title'=>'Mapa em tempo real','snapshot'=>$snapshot]);
    }

    public function updateStatus(string $id): void
    {
        Auth::requireRole(['admin','doctor','nurse']); Csrf::requireValid($_POST['_csrf']??null);
        $eid=(int)$id; $status=(string)($_POST['status']??'');
        if(!in_array($status,['aguardando_medico','em_atendimento','medicacao'],true)){Flash::set('error','Status inválido.');Response::redirect('/monitoring');}
        $db=Database::connection();
        if($status==='em_atendimento'){
            $stmt=$db->prepare("UPDATE encounters SET status=:status,care_started_at=COALESCE(care_started_at,NOW()) WHERE id=:id AND status<>'alta'");
        } else {
            $stmt=$db->prepare("UPDATE encounters SET status=:status WHERE id=:id AND status<>'alta'");
        }
        $stmt->execute(['status'=>$status,'id'=>$eid]);
        (new AuditRepository())->log('status_change','encounter',$eid,'Atualização do fluxo assistencial',['status'=>$status]);
        Flash::set('success','Status do atendimento atualizado.'); Response::redirect('/monitoring');
    }
    public function snapshot(): void {Auth::requireLogin();Response::json((new MonitoringRepository())->snapshot());}
    public function stream(): void
    {
        Auth::requireLogin();ignore_user_abort(true);set_time_limit(0);header('Content-Type: text/event-stream');header('Cache-Control: no-cache');header('X-Accel-Buffering: no');
        $repo=new MonitoringRepository();
        for($i=0;$i<20;$i++){
            if(connection_aborted())break;$payload=json_encode($repo->snapshot(),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            echo "event: snapshot\n"."data: {$payload}\n\n";@ob_flush();flush();sleep(3);
        }
        exit;
    }
}
