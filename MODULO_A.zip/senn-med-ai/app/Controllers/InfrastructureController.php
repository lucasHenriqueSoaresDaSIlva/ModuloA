<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\Csrf; use App\Core\Flash; use App\Core\Response; use App\Core\Validator; use App\Core\View;
use App\Repositories\AuditRepository; use App\Repositories\CareResourceRepository;

final class InfrastructureController
{
    public function index(): void
    {
        Auth::requireRole(['admin','nurse','doctor']);
        View::render('infrastructure/index',['title'=>'Leitos e consultórios','resources'=>(new CareResourceRepository())->all()]);
    }
    public function store(): void
    {
        Auth::requireRole('admin'); Csrf::requireValid($_POST['_csrf']??null);
        $data=$this->payload();
        if(!$data){ Flash::set('error','Preencha os campos obrigatórios corretamente.'); Response::redirect('/infrastructure'); }
        try{$id=(new CareResourceRepository())->create($data);(new AuditRepository())->log('create','care_resource',$id,'Gestão de infraestrutura');Flash::set('success','Recurso cadastrado.');}
        catch(\Throwable $e){Flash::set('error','Falha ao cadastrar. O código pode já existir.');}
        Response::redirect('/infrastructure');
    }
    public function update(string $id): void
    {
        Auth::requireRole('admin'); Csrf::requireValid($_POST['_csrf']??null); $rid=(int)$id;
        $data=$this->payload(); if(!$data){Flash::set('error','Dados inválidos.');Response::redirect('/infrastructure');}
        (new CareResourceRepository())->update($rid,$data);(new AuditRepository())->log('update','care_resource',$rid,'Gestão de infraestrutura');Flash::set('success','Recurso atualizado.');Response::redirect('/infrastructure');
    }
    private function payload(): ?array
    {
        $code=Validator::cleanText($_POST['code']??'',40);$sector=Validator::cleanText($_POST['sector']??'',100);$type=(string)($_POST['type']??'');$status=(string)($_POST['status']??'livre');
        if($code===''||$sector===''||!in_array($type,['consultorio','observacao','uti','isolamento'],true)||!in_array($status,['livre','ocupado','higienizacao','manutencao'],true))return null;
        $date=trim((string)($_POST['next_maintenance_date']??''));if($date!==''&&!Validator::date($date))return null;
        $equipment=array_values(array_filter(array_map('trim',explode(',',Validator::cleanText($_POST['equipment']??'',500)))));
        return ['code'=>$code,'sector'=>$sector,'type'=>$type,'equipment_json'=>json_encode($equipment,JSON_UNESCAPED_UNICODE),'status'=>$status,'next_maintenance_date'=>$date?:null,'notes'=>Validator::cleanText($_POST['notes']??'',500)?:null];
    }
}
