<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Core\Response;
use App\Core\Validator;
use App\Core\View;
use App\Repositories\AuditRepository;
use App\Repositories\ProfessionalRepository;
use App\Repositories\UserRepository;

final class UserController
{
    public function index(): void
    {
        Auth::requireRole('admin');
        View::render('users/index',['title'=>'Usuários','users'=>(new UserRepository())->all(),'professionals'=>(new ProfessionalRepository())->forUserLink()]);
    }

    public function store(): void
    {
        Auth::requireRole('admin'); Csrf::requireValid($_POST['_csrf']??null);
        $name=Validator::cleanText($_POST['name']??'',150); $email=trim((string)($_POST['email']??''));
        $role=(string)($_POST['role']??''); $password=(string)($_POST['password']??'');
        if($name==='' || !Validator::email($email) || !in_array($role,['admin','doctor','nurse','receptionist'],true) || strlen($password)<8){
            Flash::set('error','Dados inválidos. Use e-mail válido e senha com pelo menos 8 caracteres.'); Response::redirect('/users');
        }
        $pid=($_POST['professional_id']??'')!==''?(int)$_POST['professional_id']:null;
        if(in_array($role,['doctor','nurse'],true) && !$pid){ Flash::set('error','Médico e enfermeiro devem ser vinculados a um profissional.'); Response::redirect('/users'); }
        try{
            $id=(new UserRepository())->create(['name'=>$name,'email'=>$email,'password_hash'=>password_hash($password,PASSWORD_ARGON2ID),'role'=>$role,'professional_id'=>$pid]);
            (new AuditRepository())->log('create','user',$id,'Administração de contas',['role'=>$role]); Flash::set('success','Usuário criado com sucesso.');
        }catch(\Throwable $e){ Flash::set('error','Não foi possível criar o usuário. Verifique e-mail e vínculo profissional duplicados.'); }
        Response::redirect('/users');
    }
}
