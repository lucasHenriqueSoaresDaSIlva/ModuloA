<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth; use App\Core\View; use App\Repositories\AuditRepository;

final class AuditController
{
    public function index(): void {Auth::requireRole('admin');View::render('reports/audit',['title'=>'Auditoria LGPD','logs'=>(new AuditRepository())->recent(150)]);}
}
