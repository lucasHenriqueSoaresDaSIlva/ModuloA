<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Env;
use App\Services\AI\AiClient;

final class TriageService
{
    public const PRIORITIES = [
        'vermelho' => ['label'=>'Emergência','minutes'=>0,'weight'=>5],
        'laranja' => ['label'=>'Muito Urgente','minutes'=>10,'weight'=>4],
        'amarelo' => ['label'=>'Urgente','minutes'=>60,'weight'=>3],
        'verde' => ['label'=>'Pouco Urgente','minutes'=>120,'weight'=>2],
        'azul' => ['label'=>'Não Urgente','minutes'=>240,'weight'=>1],
    ];

    public function suggest(array $encounter): array
    {
        $sys=(int)$encounter['systolic'];
        $temp=(float)$encounter['temperature'];
        $hr=(int)$encounter['heart_rate'];
        $spo2=(int)$encounter['spo2'];
        $complaint=mb_strtolower((string)$encounter['chief_complaint']);
        $comorbid=mb_strtolower((string)($encounter['comorbidities'] ?? ''));
        $rules=[];
        $color='azul';

        $hasAny = static function(string $text,array $terms): bool {
            foreach ($terms as $term) if (str_contains($text,$term)) return true;
            return false;
        };

        if ($spo2 < 90 || $sys < 80 || $hr > 150 || $hasAny($complaint,['inconsciente','convuls','parada','não respira','nao respira'])) {
            $color='vermelho';
            $rules[]='Critério crítico: instabilidade importante ou sintoma de emergência.';
        } elseif ($spo2 < 94 || $sys < 95 || $hr >= 130 || $temp >= 40.0 || $hasAny($complaint,['dor no peito','falta de ar intensa','sangramento intenso','avc','fraqueza súbita'])) {
            $color='laranja';
            $rules[]='Critério de alta urgência: sinais vitais alterados ou queixa potencialmente grave.';
        } elseif ($spo2 < 96 || $sys < 105 || $hr >= 110 || $temp >= 38.5 || $hasAny($complaint,['dor forte','vômitos persistentes','vomitos persistentes','desidratação','desidratacao'])) {
            $color='amarelo';
            $rules[]='Critério urgente: alteração moderada de sinais vitais ou sintomas relevantes.';
        } elseif ($temp >= 37.8 || $hr >= 100 || $hasAny($complaint,['dor moderada','queda','corte','tosse','febre'])) {
            $color='verde';
            $rules[]='Critério pouco urgente: paciente estável com queixa que requer avaliação clínica.';
        } else {
            $rules[]='Critério não urgente: sinais vitais estáveis e queixa sem marcador de maior gravidade no conjunto demonstrativo.';
        }

        if ($color !== 'vermelho' && $this->hasRelevantComorbidity($comorbid)) {
            $color=$this->escalate($color);
            $rules[]='Comorbidade relevante elevou a prioridade em um nível como medida conservadora.';
        }

        $aiText=''; $aiStatus='fallback';
        $clinicalEnabled=filter_var(Env::get('AI_CLINICAL_CONTEXT_ENABLED','true'),FILTER_VALIDATE_BOOL);
        if ($clinicalEnabled) {
            $ai=new AiClient();
            $prompt="Contexto clínico pseudonimizado, sem nome, CPF ou prontuário.\n" .
                "PA: {$sys}/".(int)$encounter['diastolic']." mmHg; temperatura: {$temp} C; FC: {$hr} bpm; SpO2: {$spo2}%.\n" .
                "Queixa: ".mb_substr($complaint,0,240)."\nComorbidades: ".mb_substr($comorbid,0,180)."\n" .
                "O motor determinístico sugeriu {$color}. Explique em até 4 frases fatores de atenção e dados que o enfermeiro deve confirmar. Não altere a prioridade nem dê diagnóstico.";
            $result=$ai->ask('triage','Você é um módulo de apoio operacional de triagem. Nunca substitua o protocolo institucional nem o profissional habilitado. Não diagnostique e não emita prescrição.',$prompt,['deidentified'=>true]);
            if ($result->ok) { $aiText=$result->text; $aiStatus='available'; }
            else { $aiText='IA indisponível – modo manual. O motor determinístico e a confirmação do enfermeiro permanecem disponíveis.'; $aiStatus='fallback'; }
        } else {
            $aiText='IA clínica externa desabilitada por configuração – modo manual seguro.'; $aiStatus='disabled';
        }

        return ['suggested_color'=>$color,'priority_meta'=>self::PRIORITIES[$color],'rules'=>$rules,'ai_text'=>$aiText,'ai_status'=>$aiStatus];
    }

    public function priorityMeta(string $color): array
    {
        if (!isset(self::PRIORITIES[$color])) throw new \InvalidArgumentException('Prioridade inválida.');
        return self::PRIORITIES[$color];
    }

    private function hasRelevantComorbidity(string $text): bool
    {
        foreach (['cardiop','hipertens','diabet','asma','dpoc','câncer','cancer','imunoss','renal','gesta'] as $term) {
            if (str_contains($text,$term)) return true;
        }
        return false;
    }

    private function escalate(string $color): string
    {
        return match($color) {
            'azul'=>'verde','verde'=>'amarelo','amarelo'=>'laranja','laranja'=>'vermelho',default=>'vermelho'
        };
    }
}
