<?php
declare(strict_types=1);

namespace App\Services\AI;

final class AiResult
{
    public function __construct(
        public readonly bool $ok,
        public readonly string $text,
        public readonly string $status,
        public readonly string $provider,
        public readonly ?string $model,
        public readonly int $latencyMs,
        public readonly ?string $error = null,
    ) {}
}
