<?php
declare(strict_types=1);

namespace App\Services\AI;

interface AiProviderInterface
{
    public function generate(string $systemPrompt, string $userPrompt, int $timeoutSeconds): AiResult;
    public function name(): string;
    public function model(): ?string;
}
