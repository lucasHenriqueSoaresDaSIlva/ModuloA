<?php
declare(strict_types=1);

namespace App\Services\AI;

final class NullAiProvider implements AiProviderInterface
{
    public function __construct(private string $reason = 'API de IA não configurada') {}
    public function name(): string { return 'fallback'; }
    public function model(): ?string { return null; }
    public function generate(string $systemPrompt, string $userPrompt, int $timeoutSeconds): AiResult
    {
        return new AiResult(false, '', 'fallback', $this->name(), null, 0, $this->reason);
    }
}
