<?php
declare(strict_types=1);

namespace App\Services\AI;

use App\Core\Database;
use App\Core\Env;

final class AiClient
{
    private AiProviderInterface $provider;
    private int $timeout;

    public function __construct()
    {
        $provider = strtolower(Env::get('AI_PROVIDER', 'openai') ?? 'openai');
        $key = trim(Env::get('AI_API_KEY', '') ?? '');
        $model = trim(Env::get('AI_MODEL', $provider === 'gemini' ? 'gemini-2.0-flash' : 'gpt-4.1-mini') ?? '');
        $this->timeout = max(2, min(20, (int)(Env::get('AI_TIMEOUT_SECONDS', '6') ?? '6')));

        if ($key === '') {
            $this->provider = new NullAiProvider('Chave de API não configurada');
        } elseif ($provider === 'gemini') {
            $this->provider = new GeminiProvider($key, $model);
        } elseif ($provider === 'openai') {
            $this->provider = new OpenAIProvider($key, $model);
        } else {
            $this->provider = new NullAiProvider('Provedor de IA não reconhecido');
        }
    }

    public function ask(string $module, string $systemPrompt, string $userPrompt, array $meta = []): AiResult
    {
        try {
            $result = $this->provider->generate($systemPrompt, $userPrompt, $this->timeout);
        } catch (\Throwable $e) {
            $result = new AiResult(false, '', 'error', $this->provider->name(), $this->provider->model(), 0, $e->getMessage());
        }
        $this->log($module, $userPrompt, $result, $meta);
        return $result;
    }

    public function available(): bool
    {
        return $this->provider->name() !== 'fallback';
    }

    private function log(string $module, string $prompt, AiResult $result, array $meta): void
    {
        try {
            $stmt = Database::connection()->prepare("INSERT INTO ai_logs
                (module,provider,model,status,latency_ms,prompt_hash,request_meta_json,response_excerpt)
                VALUES (:module,:provider,:model,:status,:latency,:prompt_hash,:meta,:excerpt)");
            $status = in_array($result->status, ['success','fallback','disabled','error'], true) ? $result->status : 'error';
            $stmt->execute([
                'module' => $module,
                'provider' => $result->provider,
                'model' => $result->model,
                'status' => $status,
                'latency' => max(0, $result->latencyMs),
                'prompt_hash' => hash('sha256', $prompt),
                'meta' => $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE) : null,
                'excerpt' => mb_substr($result->text ?: ($result->error ?? ''), 0, 1000),
            ]);
        } catch (\Throwable) {
            // O log de IA jamais pode interromper o atendimento.
        }
    }
}
