<?php
declare(strict_types=1);

namespace App\Services\AI;

final class GeminiProvider implements AiProviderInterface
{
    public function __construct(private string $apiKey, private string $model) {}
    public function name(): string { return 'gemini'; }
    public function model(): ?string { return $this->model; }

    public function generate(string $systemPrompt, string $userPrompt, int $timeoutSeconds): AiResult
    {
        if (!function_exists('curl_init')) {
            return new AiResult(false, '', 'error', $this->name(), $this->model, 0, 'Extensão cURL não disponível');
        }
        $start = microtime(true);
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($this->model) . ':generateContent?key=' . rawurlencode($this->apiKey);
        $payload = json_encode([
            'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => [['role' => 'user', 'parts' => [['text' => $userPrompt]]]],
            'generationConfig' => ['temperature' => 0.2],
        ], JSON_UNESCAPED_UNICODE);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_CONNECTTIMEOUT => min(3, $timeoutSeconds),
            CURLOPT_TIMEOUT => $timeoutSeconds,
        ]);
        $body = curl_exec($ch);
        $curlError = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $latency = (int)round((microtime(true) - $start) * 1000);
        if ($body === false || $http < 200 || $http >= 300) {
            return new AiResult(false, '', 'error', $this->name(), $this->model, $latency, $curlError ?: 'HTTP ' . $http);
        }
        $json = json_decode($body, true);
        $text = trim((string)($json['candidates'][0]['content']['parts'][0]['text'] ?? ''));
        if ($text === '') {
            return new AiResult(false, '', 'error', $this->name(), $this->model, $latency, 'Resposta vazia da API');
        }
        return new AiResult(true, $text, 'success', $this->name(), $this->model, $latency);
    }
}
