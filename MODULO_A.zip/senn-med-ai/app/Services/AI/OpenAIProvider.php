<?php
declare(strict_types=1);

namespace App\Services\AI;

final class OpenAIProvider implements AiProviderInterface
{
    public function __construct(private string $apiKey, private string $model) {}
    public function name(): string { return 'openai'; }
    public function model(): ?string { return $this->model; }

    public function generate(string $systemPrompt, string $userPrompt, int $timeoutSeconds): AiResult
    {
        if (!function_exists('curl_init')) {
            return new AiResult(false, '', 'error', $this->name(), $this->model, 0, 'Extensão cURL não disponível');
        }
        $start = microtime(true);
        $payload = json_encode([
            'model' => $this->model,
            'temperature' => 0.2,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $userPrompt],
            ],
        ], JSON_UNESCAPED_UNICODE);
        if ($payload === false) {
            return new AiResult(false, '', 'error', $this->name(), $this->model, 0, 'Falha ao serializar requisição');
        }

        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $this->apiKey],
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_CONNECTTIMEOUT => min(3, $timeoutSeconds),
            CURLOPT_TIMEOUT => $timeoutSeconds,
        ]);
        $body = curl_exec($ch);
        $curlError = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $latency = (int)round((microtime(true) - $start) * 1000);
        if ($body === false || $http < 200 || $http >= 300) {
            return new AiResult(false, '', 'error', $this->name(), $this->model, $latency, $curlError ?: 'HTTP ' . $http);
        }
        $json = json_decode($body, true);
        $text = trim((string)($json['choices'][0]['message']['content'] ?? ''));
        if ($text === '') {
            return new AiResult(false, '', 'error', $this->name(), $this->model, $latency, 'Resposta vazia da API');
        }
        return new AiResult(true, $text, 'success', $this->name(), $this->model, $latency);
    }
}
