<?php
declare(strict_types=1);

namespace App\Services;

final class PdfReportService
{
    public function build(string $title,array $lines): string
    {
        $all=array_merge([$title,'Gerado em: '.date('d/m/Y H:i'),''],array_map('strval',$lines));
        $content="BT /F1 11 Tf 50 790 Td 14 TL\n";
        foreach(array_slice($all,0,48) as $i=>$line){
            $latin=iconv('UTF-8','Windows-1252//TRANSLIT',$line); if($latin===false)$latin=$line;
            $safe=str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$latin);
            $content.='('.$safe.") Tj T*\n";
        }
        $content.="ET";
        $objects=[];
        $objects[]='1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj';
        $objects[]='2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj';
        $objects[]='3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >> endobj';
        $objects[]='4 0 obj << /Length '.strlen($content).' >> stream' . "\n" . $content . "\nendstream endobj";
        $objects[]='5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj';
        $pdf="%PDF-1.4\n";$offsets=[0];
        foreach($objects as $obj){$offsets[]=strlen($pdf);$pdf.=$obj."\n";}
        $xref=strlen($pdf);$pdf.="xref\n0 6\n0000000000 65535 f \n";
        for($i=1;$i<=5;$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i])."\n";
        $pdf.="trailer << /Size 6 /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";
        return $pdf;
    }
}
