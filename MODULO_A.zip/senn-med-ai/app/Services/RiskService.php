<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Services\AI\AiClient;

final class RiskService
{
    public function analyze(): array
    {
        $stmt=Database::connection()->prepare("SELECT e.id,e.priority_color,e.max_wait_minutes,e.checkin_at,e.systolic,e.temperature,e.heart_rate,e.spo2,
          TIMESTAMPDIFF(MINUTE,e.checkin_at,NOW()) wait_minutes,p.medical_record_no
          FROM encounters e JOIN patients p ON p.id=e.patient_id WHERE e.status IN ('aguardando_triagem','aguardando_medico','medicacao') ORDER BY e.checkin_at");
        $stmt->execute(); $rows=$stmt->fetchAll(); $out=[];
        foreach($rows as $r){
            $limit=(int)($r['max_wait_minutes']??240); $wait=(int)$r['wait_minutes'];
            $timeRatio=$limit===0 ? ($wait>0?2.0:1.0) : $wait/max(1,$limit);
            $vital=0;
            if((int)$r['spo2']<94)$vital+=30; if((int)$r['systolic']<95)$vital+=25; if((int)$r['heart_rate']>=130)$vital+=20; if((float)$r['temperature']>=39.5)$vital+=15;
            $score=(int)min(100,round($timeRatio*60+$vital));
            $out[]=['encounter_id'=>(int)$r['id'],'reference'=>$r['medical_record_no'],'wait_minutes'=>$wait,'limit_minutes'=>$limit,'score'=>$score,
                'level'=>$score>=80?'critical':($score>=55?'warning':'stable'),'action'=>$score>=80?'Priorizar reavaliação profissional imediata.':($score>=55?'Reavaliar fila e disponibilidade de equipe.':'Manter monitoramento.')];
        }
        $top=array_slice(array_values(array_filter($out,fn($x)=>$x['score']>=55)),0,10);
        $aiText='Nenhum caso de risco elevado na baseline local.'; $status='fallback';
        if($top){
            $res=(new AiClient())->ask('risk','Você recebe apenas referências pseudonimizadas e métricas operacionais. Sugira ações de fluxo, nunca diagnóstico ou conduta médica.','Casos sinalizados: '.json_encode($top,JSON_UNESCAPED_UNICODE).'. Resuma prioridades operacionais em até 6 linhas.',['deidentified'=>true]);
            $aiText=$res->ok?$res->text:'IA indisponível – score local de risco e tempo permanece ativo.'; $status=$res->ok?'available':'fallback';
        }
        return ['patients'=>$out,'ai_text'=>$aiText,'ai_status'=>$status];
    }
}
