<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Env;
use App\Repositories\AlertRepository;

final class AlertService
{
    private AlertRepository $repo;
    public function __construct(){ $this->repo=new AlertRepository(); }

    public function scan(): int
    {
        $db=Database::connection(); $created=0;
        $stmt=$db->prepare("SELECT e.id,p.medical_record_no,e.max_wait_minutes,TIMESTAMPDIFF(MINUTE,e.checkin_at,NOW()) waitm
          FROM encounters e JOIN patients p ON p.id=e.patient_id WHERE e.status IN ('aguardando_medico','aguardando_triagem') AND e.max_wait_minutes IS NOT NULL
          AND TIMESTAMPDIFF(MINUTE,e.checkin_at,NOW())>e.max_wait_minutes");$stmt->execute();
        foreach($stmt->fetchAll() as $r) $created+=$this->createOnce('wait_time','critical',"Atendimento {$r['medical_record_no']} excedeu o limite de espera ({$r['waitm']} min / {$r['max_wait_minutes']} min).",'encounter',(int)$r['id']);

        $hygieneMin=max(1,(int)(Env::get('HYGIENE_ALERT_MINUTES','45')??'45'));
        $stmt=$db->prepare("SELECT id,code,TIMESTAMPDIFF(MINUTE,cleaning_started_at,NOW()) mins FROM care_resources WHERE status='higienizacao' AND cleaning_started_at IS NOT NULL AND TIMESTAMPDIFF(MINUTE,cleaning_started_at,NOW())>:m");
        $stmt->execute(['m'=>$hygieneMin]); foreach($stmt->fetchAll() as $r) $created+=$this->createOnce('hygiene','warning',"Recurso {$r['code']} está em higienização há {$r['mins']} min.",'care_resource',(int)$r['id']);

        $stmt=$db->prepare("SELECT ROUND(100*SUM(status='ocupado')/NULLIF(SUM(status<>'manutencao'),0),1) occupancy FROM care_resources");$stmt->execute();$occ=(float)$stmt->fetchColumn();
        if($occ>90) $created+=$this->createOnce('occupancy','critical',"Ocupação de recursos acima de 90%: {$occ}%.",'system',1);

        $days=max(1,(int)(Env::get('MAINTENANCE_ALERT_DAYS','7')??'7'));
        $stmt=$db->prepare("SELECT id,code,next_maintenance_date FROM care_resources WHERE next_maintenance_date IS NOT NULL AND next_maintenance_date<=DATE_ADD(CURDATE(),INTERVAL {$days} DAY)");$stmt->execute();
        foreach($stmt->fetchAll() as $r) $created+=$this->createOnce('maintenance','warning',"Manutenção preventiva de {$r['code']} prevista para {$r['next_maintenance_date']}.",'care_resource',(int)$r['id']);

        $pdays=max(1,(int)(Env::get('PROFESSIONAL_EXPIRY_ALERT_DAYS','30')??'30'));
        $stmt=$db->prepare("SELECT id,name,registration_type,registration_number,registration_expires_at FROM professionals WHERE registration_expires_at<=DATE_ADD(CURDATE(),INTERVAL {$pdays} DAY)");$stmt->execute();
        foreach($stmt->fetchAll() as $r) $created+=$this->createOnce('professional_expiry','warning',"{$r['registration_type']} {$r['registration_number']} de {$r['name']} vence em {$r['registration_expires_at']}.",'professional',(int)$r['id']);
        return $created;
    }

    private function createOnce(string $type,string $severity,string $message,string $entityType,int $entityId): int
    {
        $fingerprint=hash('sha256',implode('|',[$type,$entityType,$entityId]));
        if($this->repo->existsOpen($fingerprint)) return 0;
        $id=$this->repo->create(['type'=>$type,'severity'=>$severity,'message'=>$message,'entity_type'=>$entityType,'entity_id'=>$entityId,'fingerprint'=>$fingerprint]);
        $this->repo->logNotification($id,'panel',null,'logged','Alerta registrado no painel.');
        $email=Env::get('ALERT_EMAIL','');
        if($email){
            $res=(new EmailService())->send($email,'[SENN MED-AI] '.$severity,$message);
            $this->repo->logNotification($id,'email',$email,$res['status'],$res['detail']);
        }
        return 1;
    }
}
