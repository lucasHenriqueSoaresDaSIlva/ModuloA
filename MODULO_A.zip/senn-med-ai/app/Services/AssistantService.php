<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Services\AI\AiClient;

final class AssistantService
{
    public function answer(string $question): array
    {
        $q=mb_strtolower(trim($question));
        $db=Database::connection();
        if (preg_match('/PR-\d{4}-\d{4,6}/i', $question, $m)) {
            $record = strtoupper($m[0]);
            $stmt=$db->prepare("SELECT p.medical_record_no,e.status,e.priority_label,r.code resource_code,pr.name professional_name
                FROM patients p JOIN encounters e ON e.id=(SELECT e2.id FROM encounters e2 WHERE e2.patient_id=p.id ORDER BY e2.id DESC LIMIT 1)
                LEFT JOIN care_resources r ON r.id=e.assigned_resource_id LEFT JOIN professionals pr ON pr.id=e.assigned_professional_id
                WHERE p.medical_record_no=:record LIMIT 1");
            $stmt->execute(['record'=>$record]); $row=$stmt->fetch();
            if ($row) {
                return ['text'=>"Status de {$record}: {$row['status']}; prioridade: ".($row['priority_label']?:'não classificada')."; recurso: ".($row['resource_code']?:'não alocado')."; profissional: ".($row['professional_name']?:'não alocado').'.','source'=>'local'];
            }
            return ['text'=>"Não encontrei atendimento para {$record}.",'source'=>'local'];
        }
        if(str_contains($q,'leito') || str_contains($q,'consult')){
            $stmt=$db->prepare("SELECT status,COUNT(*) total FROM care_resources GROUP BY status");$stmt->execute();$rows=$stmt->fetchAll();
            return ['text'=>'Situação atual dos recursos: '.implode(', ',array_map(fn($r)=>$r['status'].': '.$r['total'],$rows)).'.','source'=>'local'];
        }
        if(str_contains($q,'fila') || str_contains($q,'espera')){
            $stmt=$db->prepare("SELECT COUNT(*) total,ROUND(AVG(TIMESTAMPDIFF(MINUTE,checkin_at,NOW())),1) avg_wait FROM encounters WHERE status IN ('aguardando_triagem','aguardando_medico')");$stmt->execute();$r=$stmt->fetch();
            return ['text'=>"Há {$r['total']} atendimentos em espera, com média aproximada de {$r['avg_wait']} minutos.",'source'=>'local'];
        }
        if(str_contains($q,'protocolo') || str_contains($q,'manchester')){
            return ['text'=>'Tempos configurados: Vermelho 0 min, Laranja 10 min, Amarelo 60 min, Verde 120 min e Azul 240 min. A classificação final deve ser validada pelo profissional habilitado.','source'=>'local'];
        }
        $stmt=$db->prepare("SELECT COUNT(*) total, SUM(status='livre') livres, SUM(status='ocupado') ocupados FROM care_resources");$stmt->execute();$resources=$stmt->fetch();
        $stmt=$db->prepare("SELECT COUNT(*) waiting FROM encounters WHERE status IN ('aguardando_triagem','aguardando_medico')");$stmt->execute();$waiting=$stmt->fetchColumn();
        $context=['resources'=>$resources,'waiting'=>(int)$waiting,'protocol'=>TriageService::PRIORITIES];
        $res=(new AiClient())->ask('assistant','Você é o SENN MED-AI Helper. Responda sobre uso do sistema, protocolo configurado e indicadores operacionais. Não invente dados, não diagnostique e não prescreva. Sempre lembre que saídas clínicas são suporte à decisão profissional.','Contexto operacional atual: '.json_encode($context,JSON_UNESCAPED_UNICODE)."\nPergunta do usuário: ".mb_substr($question,0,500),['aggregate_only'=>true]);
        return ['text'=>$res->ok?$res->text:'IA indisponível – modo manual. Pergunte sobre leitos, fila de espera ou tempos do protocolo para respostas locais.','source'=>$res->ok?'ai':'fallback'];
    }
}
