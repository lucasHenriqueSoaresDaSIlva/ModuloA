<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Env;

final class UploadService
{
    private const ALLOWED=['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png'];

    public function store(?array $file): array
    {
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) {
            return ['path'=>null,'original_name'=>null,'mime'=>null];
        }
        if (($file['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK) throw new \RuntimeException('Falha no upload do anexo.');
        $max=(int)(Env::get('UPLOAD_MAX_BYTES','5242880')??'5242880');
        if (($file['size']??0)>$max) throw new \InvalidArgumentException('Anexo excede o limite configurado.');
        $finfo=new \finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']);
        if (!isset(self::ALLOWED[$mime])) throw new \InvalidArgumentException('Tipo de anexo não permitido. Use PDF, JPG ou PNG.');
        $ext=self::ALLOWED[$mime]; $name=bin2hex(random_bytes(24)).'.'.$ext;
        $dest=BASE_PATH.'/storage/uploads/'.$name;
        if (!move_uploaded_file($file['tmp_name'],$dest)) throw new \RuntimeException('Não foi possível armazenar o anexo.');
        chmod($dest,0600);
        return ['path'=>$name,'original_name'=>mb_substr(basename((string)$file['name']),0,240),'mime'=>$mime];
    }
}
