<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Env;

final class EmailService
{
    public function send(string $to,string $subject,string $body): array
    {
        $enabled=filter_var(Env::get('MAIL_ENABLED','false'),FILTER_VALIDATE_BOOL);
        if(!$enabled) return ['status'=>'logged','detail'=>'MAIL_ENABLED=false; notificação preservada somente no log/painel.'];
        $from=Env::get('MAIL_FROM','no-reply@senn-med-ai.local');
        $headers="From: {$from}\r\nContent-Type: text/plain; charset=UTF-8";
        $ok=@mail($to,$subject,$body,$headers);
        return ['status'=>$ok?'sent':'failed','detail'=>$ok?'E-mail enviado por mail().':'mail() retornou falha; verifique o servidor SMTP do PHP.'];
    }
}
