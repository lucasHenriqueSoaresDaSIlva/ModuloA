<?php
declare(strict_types=1);

namespace App\Services;

use App\Repositories\AnalyticsRepository;
use App\Services\AI\AiClient;

final class OperationalAnalysisService
{
    public function analyze(int $days=30): array
    {
        $data=(new AnalyticsRepository())->operationalAggregates($days);
        $local=$this->localInsights($data);
        $res=(new AiClient())->ask('operational_analysis','Você é um analista operacional hospitalar. Trabalhe apenas com dados agregados. Não forneça diagnóstico nem decisão clínica individual.','Dados agregados: '.json_encode($data,JSON_UNESCAPED_UNICODE).'. Identifique gargalos, turnos de sobrecarga e até 5 recomendações objetivas de recursos.',['aggregate_only'=>true,'days'=>$days]);
        return ['data'=>$data,'local'=>$local,'ai_text'=>$res->ok?$res->text:'IA indisponível – análise estatística local exibida abaixo.','ai_status'=>$res->ok?'available':'fallback'];
    }

    private function localInsights(array $data): array
    {
        $hour=null;$max=-1;
        foreach($data['byHour'] as $r){ if((int)$r['total']>$max){$max=(int)$r['total'];$hour=$r['hour'];} }
        $sector=$data['bySector'][0]['sector']??'Sem dados'; $wait=$data['bySector'][0]['avg_wait']??0;
        return ["Maior volume observado por hora: {$hour}h ({$max} atendimentos no período).","Setor com maior espera média: {$sector} ({$wait} min).",'Revisar escala e recursos nos períodos de maior concentração antes de alterar fluxos clínicos.'];
    }
}
