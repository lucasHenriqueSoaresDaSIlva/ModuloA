<?php
declare(strict_types=1);

namespace App\Services;

use App\Repositories\CareResourceRepository;
use App\Repositories\ProfessionalRepository;

final class AllocationService
{
    public function allocate(array $encounter,string $priorityColor): array
    {
        $specialty=$this->specialtyFromComplaint((string)$encounter['chief_complaint']);
        $professionals=(new ProfessionalRepository())->available($specialty);
        $types=in_array($priorityColor,['vermelho','laranja'],true) ? ['uti','observacao','isolamento'] : ['consultorio','observacao','isolamento'];
        $resources=(new CareResourceRepository())->availableForTypes($types);

        return [
            'specialty'=>$specialty,
            'professional'=>$professionals[0] ?? null,
            'resource'=>$resources[0] ?? null,
            'score'=>$this->priorityScore($priorityColor,(string)$encounter['checkin_at']),
            'explanation'=>$this->explain($specialty,$professionals[0] ?? null,$resources[0] ?? null),
        ];
    }

    public function priorityScore(string $color,string $checkinAt): int
    {
        $weight=TriageService::PRIORITIES[$color]['weight'] ?? 1;
        $wait=max(0,(int)floor((time()-strtotime($checkinAt))/60));
        return $weight*100000+$wait;
    }

    private function specialtyFromComplaint(string $complaint): string
    {
        $c=mb_strtolower($complaint);
        $map=[
            'Cardiologia'=>['peito','palpita','coração','coracao'],
            'Ortopedia'=>['fratura','tornozelo','joelho','braço','braco','queda','trauma'],
            'Pediatria'=>['criança','crianca','bebê','bebe'],
            'Pneumologia'=>['falta de ar','asma','respirat','tosse'],
        ];
        foreach ($map as $specialty=>$terms) foreach ($terms as $t) if (str_contains($c,$t)) return $specialty;
        return 'Clínica Geral';
    }

    private function explain(string $specialty,?array $professional,?array $resource): string
    {
        $p=$professional ? $professional['name'].' ('.$professional['specialty'].')' : 'nenhum médico disponível';
        $r=$resource ? $resource['code'].' / '.$resource['type'] : 'nenhum leito/consultório disponível';
        return "Especialidade sugerida: {$specialty}. Melhor profissional disponível: {$p}. Recurso: {$r}.";
    }
}
