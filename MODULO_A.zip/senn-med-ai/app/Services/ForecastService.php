<?php
declare(strict_types=1);

namespace App\Services;

use App\Repositories\AnalyticsRepository;
use App\Services\AI\AiClient;

final class ForecastService
{
    public function forecast(int $days): array
    {
        if (!in_array($days, [7, 30], true)) {
            $days = 7;
        }

        $history = (new AnalyticsRepository())->dailyHistory(180);
        $daily = [];
        $severityTotals = [];
        $specialtyTotals = [];
        $grandTotal = 0;

        foreach ($history as $row) {
            $date = (string)$row['day'];
            $daily[$date] ??= ['dow' => (int)$row['dow'], 'total' => 0];
            $daily[$date]['total'] += (int)$row['total'];
            $severity = (string)$row['severity'];
            $specialty = (string)$row['specialty'];
            $severityTotals[$severity] = ($severityTotals[$severity] ?? 0) + (int)$row['total'];
            $specialtyTotals[$specialty] = ($specialtyTotals[$specialty] ?? 0) + (int)$row['total'];
            $grandTotal += (int)$row['total'];
        }

        $weekdayTotals = array_fill(1, 7, []);
        foreach ($daily as $d) {
            $weekdayTotals[$d['dow']][] = $d['total'];
        }

        $series = [];
        $periodTotal = 0;
        for ($i = 1; $i <= $days; $i++) {
            $date = date('Y-m-d', strtotime("+{$i} day"));
            $dow = (int)date('w', strtotime($date)) + 1;
            $vals = $weekdayTotals[$dow] ?? [];
            $fallbackDaily = $daily ? array_sum(array_column($daily, 'total')) / count($daily) : 0;
            $baseline = $vals ? array_sum($vals) / count($vals) : $fallbackDaily;
            $predicted = (int)max(0, round($baseline));
            $series[] = ['date' => $date, 'predicted' => $predicted];
            $periodTotal += $predicted;
        }

        $severityProjection = $this->projectBreakdown($severityTotals, $grandTotal, $periodTotal);
        $specialtyProjection = $this->projectBreakdown($specialtyTotals, $grandTotal, $periodTotal);
        $summary = [
            'period_days' => $days,
            'average' => round($periodTotal / max(1, count($series)), 1),
            'peak' => max(array_column($series, 'predicted') ?: [0]),
            'period_total' => $periodTotal,
        ];

        $payload = [
            'series' => $series,
            'projected_by_severity' => $severityProjection,
            'projected_by_specialty' => $specialtyProjection,
        ];
        $res = (new AiClient())->ask(
            'forecast',
            'Você analisa apenas dados hospitalares agregados e oferece recomendações operacionais, sem aconselhamento clínico individual.',
            'Previsão estatística local agregada para ' . $days . ' dias: ' . json_encode($payload, JSON_UNESCAPED_UNICODE) . '. Resuma em até 5 frases riscos operacionais, sazonalidade aparente e ações de capacidade. Não trate de pacientes individuais.',
            ['aggregate_only' => true, 'days' => $days]
        );

        return [
            'series' => $series,
            'summary' => $summary,
            'bySeverity' => $severityProjection,
            'bySpecialty' => $specialtyProjection,
            'ai_text' => $res->ok ? $res->text : 'IA indisponível – previsão local continua ativa.',
            'ai_status' => $res->ok ? 'available' : 'fallback',
        ];
    }

    private function projectBreakdown(array $totals, int $grandTotal, int $periodTotal): array
    {
        if ($grandTotal <= 0) {
            return [];
        }
        arsort($totals);
        $out = [];
        foreach ($totals as $label => $count) {
            $share = $count / $grandTotal;
            $out[] = [
                'label' => $label,
                'historical_share' => round($share * 100, 1),
                'predicted' => (int)round($periodTotal * $share),
            ];
        }
        return $out;
    }
}
