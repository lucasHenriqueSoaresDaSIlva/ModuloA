<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Encryption;
use App\Core\Validator;
use App\Repositories\PatientRepository;

final class CsvImportService
{
    private const HEADERS=['nome','cpf','nascimento','sexo','convenio','queixa','pressao_sistolica','pressao_diastolica','temperatura','fc','spo2','alergias','comorbidades','consentimento'];

    public function import(string $path): array
    {
        $fh=fopen($path,'rb');
        if (!$fh) throw new \RuntimeException('Não foi possível abrir o CSV.');
        $header=fgetcsv($fh,0,',');
        if (!$header) { fclose($fh); throw new \RuntimeException('CSV vazio.'); }
        $header=array_map(fn($h)=>mb_strtolower(trim((string)$h)),$header);
        if ($header !== self::HEADERS) { fclose($fh); throw new \RuntimeException('Cabeçalho CSV inválido. Use exatamente o modelo disponível no README.'); }
        $repo=new PatientRepository(); $ok=0; $errors=[]; $line=1;
        while (($row=fgetcsv($fh,0,',')) !== false) {
            $line++;
            if (count($row)!==count(self::HEADERS)) { $errors[]="Linha {$line}: quantidade de colunas inválida."; continue; }
            $d=array_combine(self::HEADERS,$row);
            try {
                $payload=$this->validateAndBuild($d,$repo);
                $repo->createPatientAndEncounter($payload['patient'],$payload['encounter']); $ok++;
            } catch (\Throwable $e) { $errors[]="Linha {$line}: ".$e->getMessage(); }
        }
        fclose($fh);
        return ['imported'=>$ok,'errors'=>$errors];
    }

    public function validateAndBuild(array $d,PatientRepository $repo): array
    {
        $name=Validator::cleanText($d['nome']??'',150); $complaint=Validator::cleanText($d['queixa']??'',500);
        if ($name==='' || $complaint==='') throw new \InvalidArgumentException('Nome e queixa são obrigatórios.');
        if (!Validator::date($d['nascimento']??'')) throw new \InvalidArgumentException('Data de nascimento inválida.');
        foreach ([['pressao_sistolica',50,260],['pressao_diastolica',30,160],['fc',25,240],['spo2',50,100]] as [$key,$min,$max])
            if (!Validator::intRange($d[$key]??null,$min,$max)) throw new \InvalidArgumentException("{$key} fora da faixa aceita.");
        if (!Validator::floatRange($d['temperatura']??null,30,45)) throw new \InvalidArgumentException('Temperatura fora da faixa aceita.');
        $cpf=Validator::cleanText($d['cpf']??'',20); $hash=Encryption::deterministicHash($cpf);
        if ($hash && $repo->cpfExists($hash)) throw new \InvalidArgumentException('CPF já cadastrado.');
        $consent=in_array(mb_strtolower(trim((string)($d['consentimento']??''))),['1','sim','true','yes'],true);
        if (!$consent) throw new \InvalidArgumentException('Consentimento/finalidade assistencial deve estar registrado.');
        $gender=strtoupper(trim((string)($d['sexo']??'N'))); if(!in_array($gender,['F','M','O','N'],true))$gender='N';
        return [
            'patient'=>[
                'medical_record_no'=>$repo->nextRecordNo(),'name'=>$name,'cpf_enc'=>Encryption::encrypt($cpf),'cpf_hash'=>$hash,
                'birth_date'=>$d['nascimento'],'gender'=>$gender,'insurance'=>Validator::cleanText($d['convenio']??'',120),
                'allergies_enc'=>Encryption::encrypt(Validator::cleanText($d['alergias']??'',500)),
                'comorbidities_enc'=>Encryption::encrypt(Validator::cleanText($d['comorbidades']??'',500)),
                'consent_given'=>1,'consent_purpose'=>'Atendimento assistencial e gestão hospitalar','consent_at'=>date('Y-m-d H:i:s'),'created_by'=>Auth::id() ?? 1,
            ],
            'encounter'=>[
                'chief_complaint_enc'=>Encryption::encrypt($complaint),'systolic'=>(int)$d['pressao_sistolica'],'diastolic'=>(int)$d['pressao_diastolica'],
                'temperature'=>(float)$d['temperatura'],'heart_rate'=>(int)$d['fc'],'spo2'=>(int)$d['spo2'],'specialty_hint'=>null,
            ]
        ];
    }
}
