<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class UserRepository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function findForLogin(string $identifier, string $role): ?array
    {
        $sql = "SELECT u.*, p.registration_number
                FROM users u
                LEFT JOIN professionals p ON p.id = u.professional_id
                WHERE u.status = 'active'
                  AND u.role = :role
                  AND (
                        u.email = :email_identifier
                        OR p.registration_number = :registration_identifier
                  )
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'role' => $role,
            'email_identifier' => $identifier,
            'registration_identifier' => $identifier,
        ]);

        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function touchLogin(int $id): void
    {
        $stmt = $this->db->prepare('UPDATE users SET last_login_at = NOW() WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }

    public function all(): array
    {
        $stmt = $this->db->prepare(
            "SELECT u.id, u.name, u.email, u.role, u.status, u.last_login_at, p.registration_number
             FROM users u
             LEFT JOIN professionals p ON p.id = u.professional_id
             ORDER BY u.name"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare(
            "INSERT INTO users (name, email, password_hash, role, professional_id, status)
             VALUES (:name, :email, :password_hash, :role, :professional_id, 'active')"
        );
        $stmt->execute($data);
        return (int) $this->db->lastInsertId();
    }

    public function admins(): array
    {
        $stmt = $this->db->prepare(
            "SELECT id, name, email
             FROM users
             WHERE role = 'admin' AND status = 'active'"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
