<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;

final class MonitoringRepository
{
    public function snapshot(): array
    {
        $db=Database::connection();
        $stmt=$db->prepare("SELECT r.id,r.code,r.sector,r.type,r.status,r.cleaning_started_at,
          e.id encounter_id,e.status patient_status,e.priority_color,p.name patient_name,pr.name professional_name
          FROM care_resources r
          LEFT JOIN encounters e ON e.assigned_resource_id=r.id AND e.status<>'alta'
          LEFT JOIN patients p ON p.id=e.patient_id
          LEFT JOIN professionals pr ON pr.id=e.assigned_professional_id
          ORDER BY r.sector,r.code");
        $stmt->execute(); $resources=$stmt->fetchAll();
        $stmt=$db->prepare("SELECT e.id,e.status,e.priority_color,e.priority_label,e.max_wait_minutes,e.checkin_at,
          TIMESTAMPDIFF(MINUTE,e.checkin_at,NOW()) wait_minutes,p.name patient_name,p.medical_record_no,
          pr.name professional_name,r.code resource_code,r.sector
          FROM encounters e JOIN patients p ON p.id=e.patient_id
          LEFT JOIN professionals pr ON pr.id=e.assigned_professional_id LEFT JOIN care_resources r ON r.id=e.assigned_resource_id
          WHERE e.status<>'alta' ORDER BY CASE e.priority_color WHEN 'vermelho' THEN 5 WHEN 'laranja' THEN 4 WHEN 'amarelo' THEN 3 WHEN 'verde' THEN 2 WHEN 'azul' THEN 1 ELSE 0 END DESC,e.checkin_at");
        $stmt->execute(); $patients=$stmt->fetchAll();
        return ['generated_at'=>date('c'),'resources'=>$resources,'patients'=>$patients];
    }
}
