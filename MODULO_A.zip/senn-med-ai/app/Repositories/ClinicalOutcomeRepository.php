<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class ClinicalOutcomeRepository
{
    private PDO $db;
    public function __construct(){ $this->db=Database::connection(); }

    public function save(int $encounterId,int $physicianUserId,array $d): ?int
    {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare("INSERT INTO clinical_outcomes
             (encounter_id,diagnosis_cid,clinical_notes_enc,prescription_enc,attachment_path,attachment_original_name,attachment_mime,physician_user_id)
             VALUES (:encounter_id,:diagnosis_cid,:clinical_notes_enc,:prescription_enc,:attachment_path,:attachment_original_name,:attachment_mime,:physician_user_id)");
            $stmt->execute([
                'encounter_id'=>$encounterId,'diagnosis_cid'=>$d['diagnosis_cid'],'clinical_notes_enc'=>$d['clinical_notes_enc'],
                'prescription_enc'=>$d['prescription_enc'],'attachment_path'=>$d['attachment_path'],'attachment_original_name'=>$d['attachment_original_name'],
                'attachment_mime'=>$d['attachment_mime'],'physician_user_id'=>$physicianUserId
            ]);
            $stmt=$this->db->prepare("SELECT assigned_resource_id,assigned_professional_id FROM encounters WHERE id=:id FOR UPDATE");
            $stmt->execute(['id'=>$encounterId]); $enc=$stmt->fetch();
            $stmt=$this->db->prepare("UPDATE encounters SET status='alta',discharged_at=NOW() WHERE id=:id");
            $stmt->execute(['id'=>$encounterId]);
            if (!empty($enc['assigned_professional_id'])) {
                $stmt=$this->db->prepare("UPDATE professionals SET availability_status='disponivel' WHERE id=:id");
                $stmt->execute(['id'=>$enc['assigned_professional_id']]);
            }
            $resourceId=!empty($enc['assigned_resource_id']) ? (int)$enc['assigned_resource_id'] : null;
            if ($resourceId) {
                $stmt=$this->db->prepare("UPDATE care_resources SET status='higienizacao',cleaning_started_at=NOW() WHERE id=:id");
                $stmt->execute(['id'=>$resourceId]);
                $stmt=$this->db->prepare("INSERT INTO hygiene_events (care_resource_id,encounter_id,started_at) VALUES (:rid,:eid,NOW())");
                $stmt->execute(['rid'=>$resourceId,'eid'=>$encounterId]);
            }
            $this->db->commit(); return $resourceId;
        } catch (\Throwable $e) { $this->db->rollBack(); throw $e; }
    }
}
