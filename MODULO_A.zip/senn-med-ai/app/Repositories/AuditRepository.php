<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Auth;
use App\Core\Database;

final class AuditRepository
{
    public function log(string $action, string $entityType, ?int $entityId, string $purpose, array $metadata = []): void
    {
        $stmt = Database::connection()->prepare("INSERT INTO audit_logs
            (user_id,action,entity_type,entity_id,purpose,ip_address,metadata_json)
            VALUES (:user_id,:action,:entity_type,:entity_id,:purpose,:ip,:metadata)");
        $stmt->execute([
            'user_id' => Auth::id(),
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'purpose' => $purpose,
            'ip' => substr($_SERVER['REMOTE_ADDR'] ?? 'cli', 0, 45),
            'metadata' => $metadata ? json_encode($metadata, JSON_UNESCAPED_UNICODE) : null,
        ]);
    }

    public function recent(int $limit = 100): array
    {
        $limit = max(1, min(500, $limit));
        $stmt = Database::connection()->prepare("SELECT a.*,u.name user_name FROM audit_logs a
            LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT {$limit}");
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
