<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class ProfessionalRepository
{
    private PDO $db;
    public function __construct(){ $this->db=Database::connection(); }

    public function all(): array
    {
        $stmt=$this->db->prepare("SELECT p.*,r.code resource_code FROM professionals p LEFT JOIN care_resources r ON r.id=p.care_resource_id ORDER BY p.name");
        $stmt->execute(); return $stmt->fetchAll();
    }

    public function create(array $d): int
    {
        $stmt=$this->db->prepare("INSERT INTO professionals
          (name,registration_type,registration_number,registration_expires_at,specialty,contact,shift_label,availability_status,care_resource_id)
          VALUES (:name,:registration_type,:registration_number,:registration_expires_at,:specialty,:contact,:shift_label,:availability_status,:care_resource_id)");
        $stmt->execute($d); return (int)$this->db->lastInsertId();
    }

    public function available(string $specialty=''): array
    {
        if ($specialty !== '') {
            $stmt=$this->db->prepare("SELECT * FROM professionals WHERE registration_type='CRM' AND availability_status='disponivel'
                AND registration_expires_at>=CURDATE() AND (LOWER(specialty)=LOWER(:specialty) OR LOWER(specialty)='clínica geral')
                ORDER BY CASE WHEN LOWER(specialty)=LOWER(:specialty2) THEN 0 ELSE 1 END, name");
            $stmt->execute(['specialty'=>$specialty,'specialty2'=>$specialty]);
        } else {
            $stmt=$this->db->prepare("SELECT * FROM professionals WHERE registration_type='CRM' AND availability_status='disponivel' AND registration_expires_at>=CURDATE() ORDER BY name");
            $stmt->execute();
        }
        return $stmt->fetchAll();
    }

    public function forUserLink(): array
    {
        $stmt=$this->db->prepare("SELECT p.id,p.name,p.registration_type,p.registration_number FROM professionals p
            LEFT JOIN users u ON u.professional_id=p.id WHERE u.id IS NULL ORDER BY p.name");
        $stmt->execute(); return $stmt->fetchAll();
    }
}
