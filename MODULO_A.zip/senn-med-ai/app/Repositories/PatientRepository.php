<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use App\Core\Encryption;
use PDO;

final class PatientRepository
{
    private PDO $db;
    public function __construct(){ $this->db=Database::connection(); }

    public function paginate(int $page=1,int $perPage=20,string $search=''): array
    {
        $page=max(1,$page); $perPage=max(5,min(100,$perPage)); $offset=($page-1)*$perPage;
        if ($search !== '') {
            $stmt=$this->db->prepare("SELECT SQL_CALC_FOUND_ROWS p.*, e.id encounter_id,e.status,e.priority_color,e.checkin_at
              FROM patients p LEFT JOIN encounters e ON e.id=(SELECT e2.id FROM encounters e2 WHERE e2.patient_id=p.id ORDER BY e2.id DESC LIMIT 1)
              WHERE p.name LIKE :q OR p.medical_record_no LIKE :q2 ORDER BY p.created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $stmt->execute(['q'=>'%'.$search.'%','q2'=>'%'.$search.'%']);
        } else {
            $stmt=$this->db->prepare("SELECT SQL_CALC_FOUND_ROWS p.*, e.id encounter_id,e.status,e.priority_color,e.checkin_at
              FROM patients p LEFT JOIN encounters e ON e.id=(SELECT e2.id FROM encounters e2 WHERE e2.patient_id=p.id ORDER BY e2.id DESC LIMIT 1)
              ORDER BY p.created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $stmt->execute();
        }
        $rows=$stmt->fetchAll();
        $count=$this->db->prepare('SELECT FOUND_ROWS()'); $count->execute(); $total=(int)$count->fetchColumn();
        return ['rows'=>$rows,'total'=>$total,'page'=>$page,'perPage'=>$perPage];
    }

    public function findEncounter(int $encounterId): ?array
    {
        $stmt=$this->db->prepare("SELECT e.*,p.name patient_name,p.medical_record_no,p.birth_date,p.gender,p.insurance,
             p.allergies_enc,p.comorbidities_enc,p.cpf_enc,pr.name professional_name,r.code resource_code,r.sector resource_sector
          FROM encounters e JOIN patients p ON p.id=e.patient_id
          LEFT JOIN professionals pr ON pr.id=e.assigned_professional_id
          LEFT JOIN care_resources r ON r.id=e.assigned_resource_id
          WHERE e.id=:id");
        $stmt->execute(['id'=>$encounterId]); $row=$stmt->fetch();
        if (!$row) return null;
        foreach (['allergies_enc'=>'allergies','comorbidities_enc'=>'comorbidities','cpf_enc'=>'cpf','chief_complaint_enc'=>'chief_complaint'] as $src=>$dst) {
            $row[$dst]=Encryption::decrypt($row[$src] ?? null);
        }
        return $row;
    }

    public function createPatientAndEncounter(array $p,array $e): int
    {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare("INSERT INTO patients
              (medical_record_no,name,cpf_enc,cpf_hash,birth_date,gender,insurance,allergies_enc,comorbidities_enc,consent_given,consent_purpose,consent_at,created_by)
              VALUES (:medical_record_no,:name,:cpf_enc,:cpf_hash,:birth_date,:gender,:insurance,:allergies_enc,:comorbidities_enc,:consent_given,:consent_purpose,:consent_at,:created_by)");
            $stmt->execute($p); $pid=(int)$this->db->lastInsertId();
            $e['patient_id']=$pid;
            $stmt=$this->db->prepare("INSERT INTO encounters
              (patient_id,chief_complaint_enc,systolic,diastolic,temperature,heart_rate,spo2,specialty_hint,status,checkin_at)
              VALUES (:patient_id,:chief_complaint_enc,:systolic,:diastolic,:temperature,:heart_rate,:spo2,:specialty_hint,'aguardando_triagem',NOW())");
            $stmt->execute($e); $eid=(int)$this->db->lastInsertId();
            $this->db->commit(); return $eid;
        } catch (\Throwable $ex) { $this->db->rollBack(); throw $ex; }
    }

    public function nextRecordNo(): string
    {
        $stmt=$this->db->prepare('SELECT COALESCE(MAX(id),0)+1 FROM patients'); $stmt->execute(); $n=(int)$stmt->fetchColumn();
        return 'PR-' . date('Y') . '-' . str_pad((string)$n, 6, '0', STR_PAD_LEFT);
    }

    public function cpfExists(?string $hash): bool
    {
        if (!$hash) return false;
        $stmt=$this->db->prepare('SELECT COUNT(*) FROM patients WHERE cpf_hash=:h'); $stmt->execute(['h'=>$hash]);
        return (int)$stmt->fetchColumn() > 0;
    }
}
