<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class TriageRepository
{
    private PDO $db;
    public function __construct(){ $this->db=Database::connection(); }

    public function queue(): array
    {
        $stmt=$this->db->prepare("SELECT e.id,e.checkin_at,e.status,e.priority_color,e.max_wait_minutes,p.name,p.medical_record_no,
             TIMESTAMPDIFF(MINUTE,e.checkin_at,NOW()) wait_minutes
          FROM encounters e JOIN patients p ON p.id=e.patient_id
          WHERE e.status IN ('aguardando_triagem','aguardando_medico')
          ORDER BY CASE e.priority_color WHEN 'vermelho' THEN 5 WHEN 'laranja' THEN 4 WHEN 'amarelo' THEN 3 WHEN 'verde' THEN 2 WHEN 'azul' THEN 1 ELSE 0 END DESC,
                   TIMESTAMPDIFF(MINUTE,e.checkin_at,NOW()) DESC");
        $stmt->execute(); return $stmt->fetchAll();
    }

    public function saveAssessment(int $encounterId,int $nurseUserId,array $assessment,array $allocation): void
    {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare("INSERT INTO triage_assessments
              (encounter_id,suggested_color,confirmed_color,nurse_user_id,override_reason,rules_json,ai_suggestion_text,ai_status)
              VALUES (:encounter_id,:suggested_color,:confirmed_color,:nurse_user_id,:override_reason,:rules_json,:ai_suggestion_text,:ai_status)");
            $stmt->execute([
                'encounter_id'=>$encounterId,'suggested_color'=>$assessment['suggested_color'],'confirmed_color'=>$assessment['confirmed_color'],
                'nurse_user_id'=>$nurseUserId,'override_reason'=>$assessment['override_reason'] ?: null,
                'rules_json'=>json_encode($assessment['rules'],JSON_UNESCAPED_UNICODE),
                'ai_suggestion_text'=>$assessment['ai_text'] ?: null,'ai_status'=>$assessment['ai_status']
            ]);
            $meta=$assessment['priority_meta'];
            $stmt=$this->db->prepare("UPDATE encounters SET priority_color=:color,priority_label=:label,max_wait_minutes=:max_wait,
              triage_confirmed_by=:uid,triage_confirmed_at=NOW(),assigned_professional_id=:pid,assigned_resource_id=:rid,
              specialty_hint=:specialty,status='aguardando_medico' WHERE id=:id");
            $stmt->execute([
                'color'=>$assessment['confirmed_color'],'label'=>$meta['label'],'max_wait'=>$meta['minutes'],'uid'=>$nurseUserId,
                'pid'=>$allocation['professional']['id'] ?? null,'rid'=>$allocation['resource']['id'] ?? null,
                'specialty'=>$allocation['specialty'] ?? null,'id'=>$encounterId
            ]);
            if (!empty($allocation['resource']['id'])) {
                $stmt=$this->db->prepare("UPDATE care_resources SET status='ocupado' WHERE id=:id AND status='livre'");
                $stmt->execute(['id'=>$allocation['resource']['id']]);
            }
            if (!empty($allocation['professional']['id'])) {
                $stmt=$this->db->prepare("UPDATE professionals SET availability_status='ocupado' WHERE id=:id AND availability_status='disponivel'");
                $stmt->execute(['id'=>$allocation['professional']['id']]);
            }
            $this->db->commit();
        } catch (\Throwable $e) { $this->db->rollBack(); throw $e; }
    }
}
