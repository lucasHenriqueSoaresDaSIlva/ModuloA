<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class AnalyticsRepository
{
    private PDO $db;
    public function __construct(){ $this->db=Database::connection(); }

    public function metrics(?string $from=null,?string $to=null): array
    {
        $from=$from ?: date('Y-m-d',strtotime('-30 days')); $to=$to ?: date('Y-m-d');
        $params=['from'=>$from.' 00:00:00','to'=>$to.' 23:59:59'];
        $stmt=$this->db->prepare("SELECT
          COUNT(*) total,
          ROUND(AVG(TIMESTAMPDIFF(MINUTE,checkin_at,care_started_at)),1) avg_wait,
          ROUND(AVG(TIMESTAMPDIFF(MINUTE,care_started_at,discharged_at)),1) avg_stay,
          ROUND(100*AVG(CASE WHEN care_started_at IS NOT NULL AND TIMESTAMPDIFF(MINUTE,checkin_at,care_started_at)<=COALESCE(max_wait_minutes,9999) THEN 1 ELSE 0 END),1) within_protocol
          FROM encounters WHERE checkin_at BETWEEN :from AND :to");
        $stmt->execute($params); $m=$stmt->fetch() ?: [];
        $stmt=$this->db->prepare("SELECT ROUND(100*SUM(status='ocupado')/NULLIF(COUNT(*),0),1) occupancy FROM care_resources WHERE status<>'manutencao'");
        $stmt->execute(); $m['occupancy']=$stmt->fetchColumn() ?: 0;
        $stmt=$this->db->prepare("SELECT COALESCE(priority_color,'sem_triagem') label,COUNT(*) value FROM encounters WHERE checkin_at BETWEEN :from AND :to GROUP BY priority_color ORDER BY value DESC");
        $stmt->execute($params); $bySeverity=$stmt->fetchAll();
        $stmt=$this->db->prepare("SELECT COALESCE(r.sector,'Sem setor') label,COUNT(*) value FROM encounters e LEFT JOIN care_resources r ON r.id=e.assigned_resource_id WHERE e.checkin_at BETWEEN :from AND :to GROUP BY r.sector ORDER BY value DESC");
        $stmt->execute($params); $bySector=$stmt->fetchAll();
        return ['from'=>$from,'to'=>$to,'summary'=>$m,'bySeverity'=>$bySeverity,'bySector'=>$bySector];
    }

    public function dailyHistory(int $days=120): array
    {
        $days=max(30,min(365,$days));
        $stmt=$this->db->prepare("SELECT DATE(checkin_at) day,DAYOFWEEK(checkin_at) dow,COALESCE(priority_color,'sem_triagem') severity,
          COALESCE(specialty_hint,'Clínica Geral') specialty,COUNT(*) total
          FROM encounters WHERE checkin_at>=DATE_SUB(CURDATE(), INTERVAL {$days} DAY)
          GROUP BY DATE(checkin_at),DAYOFWEEK(checkin_at),priority_color,specialty_hint ORDER BY day");
        $stmt->execute(); return $stmt->fetchAll();
    }

    public function operationalAggregates(int $days=30): array
    {
        $stmt=$this->db->prepare("SELECT HOUR(checkin_at) hour,COUNT(*) total,ROUND(AVG(TIMESTAMPDIFF(MINUTE,checkin_at,COALESCE(care_started_at,NOW()))),1) avg_wait
          FROM encounters WHERE checkin_at>=DATE_SUB(NOW(),INTERVAL {$days} DAY) GROUP BY HOUR(checkin_at) ORDER BY hour");
        $stmt->execute(); $byHour=$stmt->fetchAll();
        $stmt=$this->db->prepare("SELECT COALESCE(r.sector,'Sem setor') sector,COUNT(*) total,ROUND(AVG(TIMESTAMPDIFF(MINUTE,e.checkin_at,COALESCE(e.care_started_at,NOW()))),1) avg_wait
          FROM encounters e LEFT JOIN care_resources r ON r.id=e.assigned_resource_id WHERE e.checkin_at>=DATE_SUB(NOW(),INTERVAL {$days} DAY)
          GROUP BY r.sector ORDER BY avg_wait DESC");
        $stmt->execute();
        return ['byHour'=>$byHour,'bySector'=>$stmt->fetchAll()];
    }
}
