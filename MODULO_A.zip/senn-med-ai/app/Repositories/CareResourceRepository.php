<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class CareResourceRepository
{
    private PDO $db;
    public function __construct() { $this->db = Database::connection(); }

    public function all(): array
    {
        $stmt = $this->db->prepare('SELECT * FROM care_resources ORDER BY sector, code');
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM care_resources WHERE id=:id');
        $stmt->execute(['id'=>$id]);
        $row=$stmt->fetch(); return $row ?: null;
    }

    public function create(array $d): int
    {
        $stmt=$this->db->prepare("INSERT INTO care_resources
            (code,sector,type,equipment_json,status,next_maintenance_date,notes)
            VALUES (:code,:sector,:type,:equipment_json,:status,:next_maintenance_date,:notes)");
        $stmt->execute($d); return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $d): void
    {
        $d['id']=$id;
        $stmt=$this->db->prepare("UPDATE care_resources SET code=:code,sector=:sector,type=:type,
            equipment_json=:equipment_json,status=:status,next_maintenance_date=:next_maintenance_date,notes=:notes
            WHERE id=:id");
        $stmt->execute($d);
    }

    public function availableForTypes(array $types): array
    {
        if (!$types) return [];
        $ph = implode(',', array_fill(0, count($types), '?'));
        $stmt=$this->db->prepare("SELECT * FROM care_resources WHERE status='livre' AND type IN ($ph) ORDER BY FIELD(type,'uti','observacao','consultorio','isolamento'), code");
        $stmt->execute(array_values($types));
        return $stmt->fetchAll();
    }

    public function markOccupied(int $id): void
    {
        $stmt=$this->db->prepare("UPDATE care_resources SET status='ocupado',cleaning_started_at=NULL WHERE id=:id AND status='livre'");
        $stmt->execute(['id'=>$id]);
    }

    public function startCleaning(int $resourceId, int $encounterId): void
    {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare("UPDATE care_resources SET status='higienizacao',cleaning_started_at=NOW() WHERE id=:id");
            $stmt->execute(['id'=>$resourceId]);
            $stmt=$this->db->prepare("INSERT INTO hygiene_events (care_resource_id,encounter_id,started_at) VALUES (:rid,:eid,NOW())");
            $stmt->execute(['rid'=>$resourceId,'eid'=>$encounterId]);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack(); throw $e;
        }
    }

    public function cleaning(): array
    {
        $stmt=$this->db->prepare("SELECT r.*,h.id hygiene_id,h.started_at,h.encounter_id
            FROM care_resources r JOIN hygiene_events h ON h.care_resource_id=r.id AND h.completed_at IS NULL
            WHERE r.status='higienizacao' ORDER BY h.started_at");
        $stmt->execute(); return $stmt->fetchAll();
    }

    public function completeCleaning(int $hygieneId, int $userId, ?string $notes): void
    {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare('SELECT care_resource_id FROM hygiene_events WHERE id=:id AND completed_at IS NULL FOR UPDATE');
            $stmt->execute(['id'=>$hygieneId]);
            $rid=(int)($stmt->fetchColumn() ?: 0);
            if (!$rid) throw new \RuntimeException('Evento de higienização não encontrado ou já concluído.');
            $stmt=$this->db->prepare("UPDATE hygiene_events SET completed_at=NOW(),completed_by=:uid,notes=:notes WHERE id=:id");
            $stmt->execute(['uid'=>$userId,'notes'=>$notes,'id'=>$hygieneId]);
            $stmt=$this->db->prepare("UPDATE care_resources SET status='livre',cleaning_started_at=NULL WHERE id=:rid");
            $stmt->execute(['rid'=>$rid]);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack(); throw $e;
        }
    }
}
