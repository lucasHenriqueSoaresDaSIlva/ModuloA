<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;
use PDO;

final class AlertRepository
{
    private PDO $db;
    public function __construct(){ $this->db=Database::connection(); }

    public function open(): array
    {
        $stmt=$this->db->prepare('SELECT * FROM alerts WHERE resolved_at IS NULL ORDER BY FIELD(severity,\'critical\',\'warning\',\'info\'),created_at DESC');
        $stmt->execute(); return $stmt->fetchAll();
    }

    public function existsOpen(string $fingerprint): bool
    {
        $stmt=$this->db->prepare('SELECT COUNT(*) FROM alerts WHERE fingerprint=:f AND resolved_at IS NULL');
        $stmt->execute(['f'=>$fingerprint]); return (int)$stmt->fetchColumn()>0;
    }

    public function create(array $d): int
    {
        $stmt=$this->db->prepare("INSERT INTO alerts (type,severity,message,entity_type,entity_id,fingerprint) VALUES (:type,:severity,:message,:entity_type,:entity_id,:fingerprint)");
        $stmt->execute($d); return (int)$this->db->lastInsertId();
    }

    public function logNotification(int $alertId,string $channel,?string $recipient,string $status,?string $detail): void
    {
        $stmt=$this->db->prepare("INSERT INTO notification_logs (alert_id,channel,recipient,status,detail) VALUES (:aid,:channel,:recipient,:status,:detail)");
        $stmt->execute(['aid'=>$alertId,'channel'=>$channel,'recipient'=>$recipient,'status'=>$status,'detail'=>$detail]);
    }

    public function resolve(int $id,int $userId): void
    {
        $stmt=$this->db->prepare('UPDATE alerts SET resolved_at=NOW(),resolved_by=:uid WHERE id=:id AND resolved_at IS NULL');
        $stmt->execute(['uid'=>$userId,'id'=>$id]);
    }
}
