<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    public static function render(string $template, array $data = []): void
    {
        $file = BASE_PATH . '/resources/views/' . $template . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException('View não encontrada: ' . $template);
        }
        extract($data, EXTR_SKIP);
        $currentUser = Auth::user();
        $csrfToken = Csrf::token();

        ob_start();
        require $file;
        $content = ob_get_clean();

        ob_start();
        require BASE_PATH . '/resources/views/layout.php';
        $html = ob_get_clean();
        echo Url::rewriteHtml($html);
    }

    public static function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
