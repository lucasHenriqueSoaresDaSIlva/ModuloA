<?php
declare(strict_types=1);

namespace App\Core;

final class Validator
{
    public static function email(string $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function date(string $value): bool
    {
        $d = \DateTimeImmutable::createFromFormat('Y-m-d', $value);
        return $d && $d->format('Y-m-d') === $value;
    }

    public static function intRange(mixed $value, int $min, int $max): bool
    {
        $v = filter_var($value, FILTER_VALIDATE_INT);
        return $v !== false && $v >= $min && $v <= $max;
    }

    public static function floatRange(mixed $value, float $min, float $max): bool
    {
        return is_numeric($value) && (float)$value >= $min && (float)$value <= $max;
    }

    public static function cleanText(?string $value, int $maxLength = 500): string
    {
        $value = trim((string)$value);
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? '';
        return mb_substr($value, 0, $maxLength);
    }
}
