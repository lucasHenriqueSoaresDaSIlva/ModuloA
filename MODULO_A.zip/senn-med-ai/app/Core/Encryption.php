<?php
declare(strict_types=1);

namespace App\Core;

final class Encryption
{
    private static function key(): string
    {
        $configured = Env::get('APP_ENCRYPTION_KEY', '');
        if (str_starts_with($configured, 'base64:')) {
            $decoded = base64_decode(substr($configured, 7), true);
            if ($decoded !== false && strlen($decoded) >= 32) {
                return substr($decoded, 0, 32);
            }
        }
        return hash('sha256', $configured ?: 'development-only-key', true);
    }

    public static function encrypt(?string $plaintext): ?string
    {
        if ($plaintext === null || $plaintext === '') {
            return $plaintext;
        }
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plaintext, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) {
            throw new \RuntimeException('Falha ao criptografar dado sensível.');
        }
        return base64_encode($iv . $tag . $cipher);
    }

    public static function decrypt(?string $encoded): ?string
    {
        if ($encoded === null || $encoded === '') {
            return $encoded;
        }
        $raw = base64_decode($encoded, true);
        if ($raw === false || strlen($raw) < 29) {
            return '[dado protegido inválido]';
        }
        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $cipher = substr($raw, 28);
        $plain = openssl_decrypt($cipher, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        return $plain === false ? '[falha ao descriptografar]' : $plain;
    }

    public static function deterministicHash(?string $value): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }
        return hash_hmac('sha256', preg_replace('/\D+/', '', $value), self::key());
    }
}
