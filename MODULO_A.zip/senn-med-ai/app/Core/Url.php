<?php
declare(strict_types=1);

namespace App\Core;

final class Url
{
    public static function basePath(): string
    {
        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        if ($script === '' || $script === '/') {
            return '';
        }

        $dir = str_replace('\\', '/', dirname($script));
        if ($dir === '/' || $dir === '.' || $dir === '\\') {
            return '';
        }

        return rtrim($dir, '/');
    }

    public static function to(string $path = '/'): string
    {
        if ($path === '') {
            $path = '/';
        }
        if (preg_match('#^(?:https?:)?//#i', $path) || str_starts_with($path, '#') || str_starts_with($path, '?')) {
            return $path;
        }

        $base = self::basePath();
        return $base . '/' . ltrim($path, '/');
    }

    public static function requestPath(string $uri): string
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $base = self::basePath();

        if ($base !== '' && ($path === $base || str_starts_with($path, $base . '/'))) {
            $path = substr($path, strlen($base));
            if ($path === '') {
                $path = '/';
            }
        }

        return '/' . ltrim($path, '/');
    }

    public static function rewriteHtml(string $html): string
    {
        $base = self::basePath();
        if ($base === '') {
            return $html;
        }

        return preg_replace_callback(
            "#\\b(href|src|action)=([\"'])/(?!/)#i",
            static fn(array $m): string => $m[1] . '=' . $m[2] . $base . '/',
            $html
        ) ?? $html;
    }
}
