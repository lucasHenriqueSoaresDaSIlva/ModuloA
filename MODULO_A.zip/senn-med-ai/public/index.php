<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
$router = require BASE_PATH . '/config/routes.php';
$router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/');
