(() => {
  const base = window.__APP_BASE__ || '';
  const appUrl = (path) => `${base}${path.startsWith('/') ? path : '/' + path}`;
  let data = window.__MONITORING__ || {resources:[],patients:[]};
  const grid=document.getElementById('resourceGrid'), rows=document.getElementById('patientRows'), status=document.getElementById('liveStatus');
  const fSector=document.getElementById('filterSector'), fDoctor=document.getElementById('filterDoctor'), fPriority=document.getElementById('filterPriority');
  const esc = (s) => String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
  const csrf=document.querySelector('meta[name="csrf-token"]')?.content || '';
  const options=(select,values,label)=>{const current=select.value;select.innerHTML=`<option value="">${label}</option>`+[...new Set(values.filter(Boolean))].sort().map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');select.value=current;};
  function render(){
    options(fSector,data.resources.map(r=>r.sector),'Todas'); options(fDoctor,data.patients.map(p=>p.professional_name),'Todos');
    const sector=fSector.value,doctor=fDoctor.value,priority=fPriority.value;
    grid.innerHTML=data.resources.filter(r=>!sector||r.sector===sector).map(r=>`<article class="resource-card" data-status="${esc(r.status)}"><h3>${esc(r.code)}</h3><div>${esc(r.sector)} · ${esc(r.type)}</div><div class="resource-status">${esc(r.status)}</div>${r.patient_name?`<p><strong>${esc(r.patient_name)}</strong><br>${esc(r.patient_status)}<br>${esc(r.professional_name||'Sem médico')}</p>`:'<p class="muted">Sem paciente vinculado</p>'}</article>`).join('');
    rows.innerHTML=data.patients.filter(p=>(!sector||p.sector===sector)&&(!doctor||p.professional_name===doctor)&&(!priority||p.priority_color===priority)).map(p=>`<tr><td>${esc(p.medical_record_no)}</td><td>${esc(p.patient_name)}</td><td>${esc(p.status)}</td><td>${p.priority_color?`<span class="tag priority-${esc(p.priority_color)}">● ${esc(p.priority_label||p.priority_color)}</span>`:'—'}</td><td>${esc(p.wait_minutes)} min</td><td>${esc(p.professional_name||'—')}</td><td>${esc(p.resource_code||'—')}</td><td><div class="actions">${window.__CAN_UPDATE__ ? ['aguardando_medico','em_atendimento','medicacao'].map(s=>`<form method="post" action="${appUrl(`/encounters/${Number(p.id)}/status`)}"><input type="hidden" name="_csrf" value="${esc(csrf)}"><input type="hidden" name="status" value="${s}"><button class="secondary" type="submit">${s.replaceAll('_',' ')}</button></form>`).join('') : ''}${window.__CAN_CLINICAL__ ? `<a href="${appUrl(`/clinical/${Number(p.id)}`)}">Desfecho</a>` : ''}</div></td></tr>`).join('');
  }
  [fSector,fDoctor,fPriority].forEach(x=>x?.addEventListener('change',render)); render();
  let polling=null;
  const startPolling=()=>{if(polling)return;status.textContent='Polling';polling=setInterval(async()=>{try{const r=await fetch(appUrl('/api/monitoring-snapshot'),{cache:'no-store'});if(r.ok){data=await r.json();render();}}catch(_){status.textContent='Offline';}},5000);};
  if('EventSource' in window){const es=new EventSource(appUrl('/events/monitoring'));es.addEventListener('snapshot',ev=>{try{data=JSON.parse(ev.data);status.textContent='SSE ao vivo';render();}catch(_){}});es.onerror=()=>{es.close();startPolling();};}else startPolling();
})();
