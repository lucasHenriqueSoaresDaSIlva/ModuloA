(() => {
  const base = window.__APP_BASE__ || '';
  const appUrl = (path) => `${base}${path.startsWith('/') ? path : '/' + path}`;

  // Navegação lateral responsiva
  const navToggle = document.getElementById('navToggle');
  const navClose = document.getElementById('navClose');
  const nav = document.getElementById('mainNav');
  const overlay = document.getElementById('navOverlay');

  const setNav = (open) => {
    if (!nav) return;
    nav.classList.toggle('open', open);
    navToggle?.setAttribute('aria-expanded', String(open));
    if (overlay) overlay.hidden = !open;
    document.body.classList.toggle('nav-open', open);
  };

  navToggle?.addEventListener('click', () => setNav(!nav?.classList.contains('open')));
  navClose?.addEventListener('click', () => setNav(false));
  overlay?.addEventListener('click', () => setNav(false));
  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    if (window.innerWidth <= 1100) setNav(false);
  }));

  // Destaca item ativo da navegação
  const currentPath = window.location.pathname.replace(base, '') || '/';
  nav?.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href') || '';
    const normalized = href.split('?')[0];
    const active = normalized === '/dashboard'
      ? currentPath === '/dashboard' || currentPath === '/'
      : currentPath === normalized || currentPath.startsWith(normalized + '/');
    if (active) link.classList.add('active');
  });

  // Chat SENN MED-AI Helper
  const chatOpen = document.getElementById('chatOpen');
  const chatClose = document.getElementById('chatClose');
  const panel = document.getElementById('chatPanel');
  const form = document.getElementById('chatForm');
  const messages = document.getElementById('chatMessages');
  const question = document.getElementById('chatQuestion');
  const sendButton = document.getElementById('chatSend');
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

  const setChat = (open) => {
    if (!panel || !chatOpen) return;
    panel.hidden = !open;
    chatOpen.setAttribute('aria-expanded', String(open));
    chatOpen.classList.toggle('is-hidden', open);
    if (open) setTimeout(() => question?.focus(), 40);
  };

  const appendMessage = (role, text) => {
    if (!messages) return null;
    const item = document.createElement('div');
    item.className = `chat-message ${role}`;
    item.textContent = text;
    messages.appendChild(item);
    messages.scrollTop = messages.scrollHeight;
    return item;
  };

  const setLoading = (loading) => {
    if (!sendButton || !question) return;
    sendButton.disabled = loading;
    question.disabled = loading;
    sendButton.textContent = loading ? 'Enviando...' : 'Enviar';
  };

  chatOpen?.addEventListener('click', () => setChat(true));
  chatClose?.addEventListener('click', () => setChat(false));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && panel && !panel.hidden) setChat(false);
  });

  question?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      form?.requestSubmit();
    }
  });

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!question || !messages) return;

    const text = question.value.trim();
    if (!text) return;

    appendMessage('user', text);
    question.value = '';
    const loadingMessage = appendMessage('assistant', 'Consultando informações do sistema...');
    setLoading(true);

    try {
      const body = new URLSearchParams({ question: text, _csrf: csrf });
      const response = await fetch(appUrl('/api/assistant'), {
        method: 'POST',
        headers: {
          'X-CSRF-Token': csrf,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        },
        body
      });

      const raw = await response.text();
      let data;
      try { data = JSON.parse(raw); }
      catch (_) { throw new Error('O servidor retornou uma resposta inválida.'); }

      if (!response.ok) throw new Error(data.error || 'Falha ao consultar o assistente.');
      if (loadingMessage) loadingMessage.textContent = data.text || 'Não foi possível gerar uma resposta.';
    } catch (error) {
      if (loadingMessage) {
        loadingMessage.textContent = error.message || 'IA indisponível – modo manual. O sistema principal continua funcionando.';
      }
    } finally {
      setLoading(false);
      if (messages) messages.scrollTop = messages.scrollHeight;
      question.focus();
    }
  });
})();
