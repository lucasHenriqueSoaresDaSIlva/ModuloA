(() => {
  const drawRoundedRect = (ctx, x, y, width, height, radius) => {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, r);
    ctx.fill();
  };

  const draw = (canvas) => {
    const data = JSON.parse(canvas.dataset.chart || '[]');
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const cssHeight = 280;
    canvas.width = Math.max(360, Math.floor(rect.width * dpr));
    canvas.height = cssHeight * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    const width = canvas.width / dpr;
    const height = cssHeight;
    ctx.clearRect(0, 0, width, height);

    if (!data.length) {
      ctx.fillStyle = '#64748b';
      ctx.font = '500 13px Inter, system-ui, sans-serif';
      ctx.fillText('Sem dados no período selecionado.', 24, 42);
      return;
    }

    const padLeft = 44;
    const padRight = 18;
    const padTop = 28;
    const padBottom = 58;
    const graphHeight = height - padTop - padBottom;
    const graphWidth = width - padLeft - padRight;
    const max = Math.max(...data.map(x => Number(x.value) || 0), 1);

    // grades horizontais
    ctx.strokeStyle = '#e6edf5';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#8090a6';
    ctx.font = '500 11px Inter, system-ui, sans-serif';
    for (let i = 0; i <= 4; i++) {
      const y = padTop + (graphHeight / 4) * i;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
      const value = Math.round(max - (max / 4) * i);
      ctx.fillText(String(value), 8, y + 4);
    }

    const slot = graphWidth / data.length;
    const barWidth = Math.min(54, Math.max(22, slot * 0.56));
    const gradient = ctx.createLinearGradient(0, padTop, 0, height - padBottom);
    gradient.addColorStop(0, '#1877d5');
    gradient.addColorStop(1, '#0b5cab');

    data.forEach((item, index) => {
      const value = Number(item.value) || 0;
      const barHeight = Math.max(3, graphHeight * (value / max));
      const x = padLeft + slot * index + (slot - barWidth) / 2;
      const y = padTop + graphHeight - barHeight;

      ctx.fillStyle = gradient;
      drawRoundedRect(ctx, x, y, barWidth, barHeight, 8);

      ctx.fillStyle = '#25364f';
      ctx.font = '700 11px Inter, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(String(value), x + barWidth / 2, Math.max(16, y - 8));

      ctx.fillStyle = '#64748b';
      ctx.font = '500 11px Inter, system-ui, sans-serif';
      const label = String(item.label || '').slice(0, 14);
      ctx.save();
      ctx.translate(x + barWidth / 2, height - 30);
      ctx.rotate(-0.25);
      ctx.fillText(label, 0, 0);
      ctx.restore();
    });
    ctx.textAlign = 'left';
  };

  const redraw = () => document.querySelectorAll('canvas[data-chart]').forEach(draw);
  redraw();
  let timer;
  window.addEventListener('resize', () => {
    clearTimeout(timer);
    timer = setTimeout(redraw, 120);
  });
})();
