<?php
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));

// Polyfills mínimos para ambientes de prova sem mbstring. Em produção, habilite a extensão.
if (!function_exists('mb_substr')) { function mb_substr(string $s, int $start, ?int $length = null): string { return $length === null ? substr($s, $start) : substr($s, $start, $length); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower(string $s): string { return strtolower($s); } }

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = BASE_PATH . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

use App\Core\Env;

Env::load(BASE_PATH . '/.env');

date_default_timezone_set(Env::get('APP_TIMEZONE', 'America/Sao_Paulo'));

$secure = filter_var(Env::get('SESSION_SECURE', 'false'), FILTER_VALIDATE_BOOL);
session_name(Env::get('SESSION_NAME', 'senn_med_ai_session'));
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $secure,
    'httponly' => true,
    'samesite' => 'Strict',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (filter_var(Env::get('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOL)) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
}

set_exception_handler(function (Throwable $e): void {
    $message = '[' . date('c') . '] ' . $e::class . ': ' . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n\n";
    @file_put_contents(BASE_PATH . '/storage/logs/app.log', $message, FILE_APPEND | LOCK_EX);
    http_response_code(500);
    if (filter_var(App\Core\Env::get('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOL)) {
        echo '<h1>Erro interno</h1><pre>' . htmlspecialchars($e->getMessage() . "\n" . $e->getTraceAsString(), ENT_QUOTES, 'UTF-8') . '</pre>';
    } else {
        echo '<h1>Erro interno</h1><p>Ocorreu um erro. Tente novamente.</p>';
    }
});
