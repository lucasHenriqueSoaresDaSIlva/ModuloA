# Roteiro de commits

O pacote foi preparado com commits pequenos e semânticos. Ao continuar o desenvolvimento, mantenha o mesmo padrão:

1. `docs: analisar requisitos e definir arquitetura`
2. `feat: criar núcleo seguro da aplicação e configuração de ambiente`
3. `feat: modelar banco MySQL e dados iniciais`
4. `fix: alinhar hashes determinísticos do seed`
5. `feat: adicionar camada de repositórios e auditoria`
6. `feat: implementar triagem, alocação, IA, fallback e serviços operacionais`
7. `feat: implementar controladores dos fluxos hospitalares`
8. `feat: permitir transição segura do fluxo de atendimento`
9. `feat: criar layout responsivo acessível e assistente integrado`
10. `feat: entregar dashboard, cadastros e recepção`
11. `feat: implementar triagem, mapa em tempo real, desfecho e higienização`
12. `feat: finalizar módulos de IA, alertas, auditoria e rotas`
13. `fix: tornar fallback robusto sem extensões opcionais`
14. `docs: concluir manual, backup, testes e entrega`
