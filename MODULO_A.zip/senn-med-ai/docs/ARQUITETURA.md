# Arquitetura

## Estrutura de pastas

```text
app/
  Core/            infraestrutura: DB, sessão, autenticação, CSRF, view, env
  Controllers/     entrada HTTP e autorização
  Repositories/    SQL parametrizado e persistência
  Services/        regras de negócio
    AI/             contrato e provedores OpenAI/Gemini/fallback
config/             bootstrap e rotas
database/           schema.sql e seed.sql
public/             front controller e assets
resources/views/    templates HTML
bin/                backup, alertas e utilitários CLI
docs/               arquitetura, manual, rastreabilidade e entrega
tests/              testes automatizados leves
storage/            uploads, logs e backups
```

## Modelo entidade-relacionamento

```text
professionals 1 ─── 0..1 users
users 1 ─── N audit_logs
users 1 ─── N patients (created_by)
patients 1 ─── N encounters
encounters 1 ─── N triage_assessments
encounters N ─── 0..1 professionals (assigned)
encounters N ─── 0..1 care_resources (assigned)
encounters 1 ─── 0..1 clinical_outcomes
care_resources 1 ─── N hygiene_events
alerts 1 ─── N notification_logs
```

### Tabelas e índices centrais

- `users`: índice único em e-mail, índice em papel/status.
- `professionals`: registro profissional único, índices em especialidade, disponibilidade e validade.
- `care_resources`: código único; índices por setor, status e tipo.
- `patients`: prontuário único e hash de CPF único.
- `encounters`: índices em status, prioridade, check-in, médico, leito e combinação `status + priority_color + checkin_at`.
- `triage_assessments`: índice por atendimento/data.
- `clinical_outcomes`: atendimento único e médico/data.
- `alerts`: índice por status de resolução, tipo e data.
- `audit_logs`: índices por usuário, entidade e data.

## Rotas principais

```text
GET|POST /login
POST     /logout
GET      /dashboard
GET|POST /users
GET|POST /infrastructure
GET|POST /professionals
GET|POST /patients
GET|POST /patients/import
GET|POST /triage/{id}
GET      /monitoring
GET      /events/monitoring
GET      /api/monitoring-snapshot
GET|POST /clinical/{id}
GET      /ai/forecast
GET      /ai/risk
GET|POST /ai/analysis
POST     /api/assistant
GET      /alerts
POST     /alerts/scan
POST     /alerts/{id}/resolve
GET      /reports/export?format=pdf|xls
GET      /hygiene
POST     /hygiene/{id}/complete
```

## Algoritmo de alocação

A prioridade efetiva combina gravidade e espera acumulada. Internamente cada cor recebe um peso base e a espera acrescenta pontos. O sistema procura, na ordem:

1. profissional disponível com especialidade sugerida pela queixa;
2. profissional disponível de clínica geral, se não houver especialista;
3. recurso livre do tipo apropriado à gravidade;
4. fallback para qualquer consultório/observação livre compatível.

Vermelho/Laranja preferem UTI/Observação; demais preferem Consultório/Observação. Se não existir combinação, o paciente permanece em fila e o painel informa ausência de recurso.

## Diagrama de fluxo da triagem

```mermaid
flowchart TD
    A[Paciente registrado] --> B[Enfermeiro abre triagem]
    B --> C[Validar sinais vitais e queixa]
    C --> D[Motor determinístico]
    D --> E[Sugestão de cor + justificativas]
    E --> F{API IA disponível?}
    F -- Sim --> G[Complemento pseudonimizado]
    F -- Não --> H[Modo manual/fallback]
    G --> I[Exibir aviso clínico]
    H --> I
    I --> J{Enfermeiro confirma?}
    J -- Confirma --> K[Salvar classificação]
    J -- Altera --> L[Registrar nova cor + justificativa]
    L --> K
    K --> M[Fila de prioridade]
    M --> N[Selecionar médico e leito]
    N --> O[Aguardando médico / atendimento]
```
