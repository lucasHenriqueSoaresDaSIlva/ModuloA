# SENN MED-AI — Análise e rastreabilidade

Este documento registra as decisões tomadas antes da implementação. O projeto é um protótipo educacional para o SENAI Dev Experience 2026 e não substitui software clínico certificado nem julgamento profissional.

## Ambiguidades e decisões

1. **"IA" na triagem:** o caderno aceita IA ou algoritmos baseados no Protocolo de Manchester. Foi adotado um motor determinístico obrigatório e auditável, com enriquecimento opcional por API externa. A decisão final sempre pertence ao enfermeiro.
2. **Manchester:** o caderno fornece as cinco classes e tempos, mas não uma árvore clínica oficial completa. Foi implementada uma árvore simplificada e documentada para demonstração, usando sinais vitais, queixa e comorbidades. Não é uma implementação certificada do Manchester Triage System.
3. **Tempo real:** foi escolhido SSE por simplicidade e baixa latência, com fallback automático para polling.
4. **Exportação Excel:** sem dependência externa, o sistema gera arquivo `.xls` compatível com Excel por tabela HTML. PDF é gerado por um serviço PHP próprio e simples.
5. **E-mail:** o sistema usa `mail()` quando habilitado e sempre registra tentativa/resultado em log. Em ambiente sem servidor de e-mail, o alerta no painel continua funcional.
6. **LGPD e IA externa:** nenhum identificador direto de paciente é enviado à API externa. Contexto clínico para IA é pseudonimizado e pode ser desabilitado por variável de ambiente.
7. **Criptografia em repouso:** textos clínicos sensíveis, CPF e dados livres de saúde são protegidos com AES-256-GCM; o hash do CPF permite detecção de duplicidade sem descriptografar.
8. **RF14 bônus:** foi adicionado um fluxo de higienização de leito, aproveitando a exigência do RF07 e os alertas do RF11, sem alterar os 13 requisitos obrigatórios.

## Tabela de rastreabilidade

| Req. | Implementação | Arquivos principais |
|---|---|---|
| RF01 | Cadastro/autenticação, quatro perfis, RBAC no servidor | `app/Controllers/AuthController.php`, `UserController.php`, `app/Core/Auth.php`, `resources/views/users/*` |
| RF02 | CRUD de leitos/consultórios, equipamentos, status, manutenção | `InfrastructureController.php`, `CareResourceRepository.php`, `resources/views/infrastructure/*` |
| RF03 | Cadastro de profissionais, CRM/COREN, validade, especialidade, turno | `ProfessionalController.php`, `ProfessionalRepository.php`, `resources/views/professionals/*` |
| RF04 | Cadastro manual e importação CSV validada | `PatientController.php`, `CsvImportService.php`, `PatientRepository.php`, `resources/views/patients/*` |
| RF05 | Triagem determinística + sugestão IA + confirmação/override + alocação | `TriageController.php`, `TriageService.php`, `AllocationService.php`, `resources/views/triage/*` |
| RF06 | Mapa CSS Grid, fila/status, filtros, SSE e polling | `MonitoringController.php`, `MonitoringRepository.php`, `resources/views/monitoring/index.php`, `public/assets/js/monitoring.js` |
| RF07 | CID, conduta, evolução, anexo, data/médico automáticos, leito em higienização | `ClinicalOutcomeController.php`, `ClinicalOutcomeRepository.php`, `UploadService.php` |
| RF08 | Previsão 7/30 dias por média sazonal local + enriquecimento IA | `ForecastService.php`, `AIController.php`, `resources/views/ai/forecast.php` |
| RF09 | Risco temporal/clínico local + enriquecimento IA + sinalização | `RiskService.php`, `AIController.php`, `resources/views/ai/risk.php` |
| RF10 | Métricas, gráficos, filtros, PDF e Excel | `DashboardController.php`, `AnalyticsRepository.php`, `ExportController.php`, `PdfReportService.php` |
| RF11 | Alertas de espera, higienização, ocupação, manutenção e validade profissional; e-mail, resolução e log | `AlertService.php`, `AlertsController.php`, `bin/scan_alerts.php` |
| RF12 | Insights de gargalos/sobrecarga/recomendações sobre dados agregados | `OperationalAnalysisService.php`, `AIController.php`, `resources/views/ai/analysis.php` |
| RF13 | Chatbot integrado com consultas operacionais locais e IA opcional | `AssistantService.php`, `AIController.php`, `resources/views/partials/chat.php` |
| RF14 bônus | Gestão de higienização e retorno do leito ao estado livre | `HygieneController.php`, `resources/views/hygiene/index.php` |
| RNF01 | Hash de senha, sessões seguras, PDO, CSRF, escaping, uploads, AES-256-GCM, auditoria | `app/Core/*`, `UploadService.php`, `AuditRepository.php` |
| RNF02 | Índices, paginação e queries agregadas | `database/schema.sql`, repositórios |
| RNF03 | Responsivo, teclado, foco, labels/ARIA e rótulos além de cor | `public/assets/css/app.css`, views |
| RNF04 | SSE com fallback polling | `MonitoringController.php`, `public/assets/js/monitoring.js` |
| RNF05 | Backup mysqldump, rotação e restauração documentada | `bin/backup.sh`, `docs/BACKUP_RESTORE.md` |
| RNF06 | IA desacoplada, timeout e fallback integral | `Services/AI/*`, serviços de triagem/alocação |
| RNF07 | MVC + services + repositories + interface de IA | `app/` |
| RNF08 | Minimização, criptografia, auditoria, finalidade/consentimento, relatórios agregados | `database/schema.sql`, `Encryption.php`, `AuditRepository.php` |
| RNF09 | Manual por perfil e suporte básico | `docs/MANUAL_USUARIO.md` |

## Tempos máximos adotados

- Vermelho: 0 min
- Laranja: 10 min
- Amarelo: 60 min
- Verde: 120 min
- Azul: 240 min

## Fluxo de triagem

1. Recepção cria/importa paciente e gera atendimento.
2. Enfermeiro abre a ficha.
3. Motor de regras calcula uma sugestão baseada em sinais vitais, queixa e comorbidades.
4. Módulo de IA externa, quando disponível, apenas complementa a explicação; não decide sozinho.
5. Enfermeiro confirma ou altera a prioridade e registra justificativa de override quando necessário.
6. `AllocationService` calcula a melhor combinação de profissional e recurso disponível por prioridade, especialidade, disponibilidade e tipo.
7. Atendimento entra na fila médica; mapa e dashboard recebem atualização via SSE.
8. Médico registra desfecho; recurso vai para higienização.
9. Higienização é concluída e o recurso volta a `livre`.
