# Texto curto para o PDF de entrega

**SENN MED-AI — Smart Care** é uma plataforma web de gestão hospitalar para cadastro de pacientes, profissionais, leitos e consultórios, triagem baseada nas cinco prioridades do Protocolo de Manchester, alocação automática de recursos, mapa de ocupação em tempo real, desfecho clínico, alertas e indicadores gerenciais. O sistema inclui previsão de demanda, análise de risco, insights operacionais e o assistente SENN MED-AI Helper, sempre com fallback quando a API externa de IA estiver indisponível. O projeto aplica controle de acesso por perfil, proteção contra SQL Injection/XSS/CSRF, criptografia de dados sensíveis, auditoria e práticas de LGPD.

**Repositório:** `COLE_AQUI_O_LINK_DO_GITHUB`

## Acesso dos avaliadores no GitHub

No GitHub: **Settings → Collaborators / Manage access → Add people** e adicione:

- `Cardoso30S`
- `fiorezewesley`
- `Greggori`

Confirme que os três usuários conseguem visualizar o repositório antes da entrega.

## ZIP

Na pasta que contém o projeto:

```bash
zip -r moduloA_nomeEquipe.zip senn-med-ai -x 'senn-med-ai/.env' 'senn-med-ai/storage/uploads/*' 'senn-med-ai/storage/logs/*' 'senn-med-ai/storage/backups/*'
```

No Windows PowerShell, depois de remover `.env` do pacote de entrega ou confirmar que ele está excluído:

```powershell
Compress-Archive -Path .\senn-med-ai\* -DestinationPath .\moduloA_nomeEquipe.zip -Force
```

Use o nome real da equipe no lugar de `nomeEquipe`.
