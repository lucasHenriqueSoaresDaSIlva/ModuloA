# Relatório de testes

Data da validação do pacote: 2026-10-19.

## Executado com sucesso

- `php tests/run.php`: **8/8 testes aprovados**.
- Lint de todos os arquivos PHP em `app/`, `config/`, `public/`, `resources/views/`, `bin/` e `tests/`: **0 erros de sintaxe**.
- Smoke test HTTP com servidor embutido do PHP: `GET /login` retornou **HTTP 200** e renderizou a identidade `SENN MED-AI`.
- Verificação dos hashes de senha do `seed.sql`: as senhas documentadas foram validadas com `password_verify`.
- PDF-fonte da prova renderizado em 6 páginas e revisado visualmente para confirmar requisitos técnicos e entrega.

## Cobertura dos testes unitários leves

1. round-trip AES-256-GCM;
2. hash determinístico de CPF;
3. faixas de validação numérica;
4. classificação crítica em vermelho;
5. classificação estável em azul;
6. elevação conservadora por comorbidade no motor demonstrativo;
7. precedência da gravidade no score da fila;
8. assinatura/estrutura básica do PDF gerado.

## Limitação do ambiente de execução usado para montar o pacote

O ambiente atual possui PHP CLI, porém **não possui servidor MySQL nem a extensão `pdo_mysql`**, portanto não foi possível executar um teste de integração real do banco nesta máquina. O projeto inclui `schema.sql`, `seed.sql` e `bin/healthcheck.php` para validação imediata no ambiente final com MySQL.

Antes da apresentação, execute obrigatoriamente:

```bash
php bin/healthcheck.php
php tests/run.php
```

Depois faça o fluxo de smoke test listado em `README.md`: login, cadastro de paciente, triagem, mapa, alteração de status, alta, higienização, dashboard, exportação e alertas.
