# Checklist final de requisitos

| ID | Status | Evidência principal |
|---|---|---|
| RF01 | ✅ | `AuthController.php`, `UserController.php`, `Auth.php`, `users/index.php` |
| RF02 | ✅ | `InfrastructureController.php`, `CareResourceRepository.php` |
| RF03 | ✅ | `ProfessionalController.php`, `ProfessionalRepository.php` |
| RF04 | ✅ | `PatientController.php`, `CsvImportService.php` |
| RF05 | ✅ | `TriageService.php`, `AllocationService.php`, `TriageController.php` |
| RF06 | ✅ | `MonitoringController.php`, `MonitoringRepository.php`, `monitoring.js` |
| RF07 | ✅ | `ClinicalOutcomeController.php`, `ClinicalOutcomeRepository.php`, `UploadService.php` |
| RF08 | ✅ | `ForecastService.php`, `ai/forecast.php` |
| RF09 | ✅ | `RiskService.php`, `ai/risk.php` |
| RF10 | ✅ | `DashboardController.php`, `AnalyticsRepository.php`, `ExportController.php` |
| RF11 | ✅ | `AlertService.php`, `AlertsController.php`, `bin/scan_alerts.php` |
| RF12 | ✅ | `OperationalAnalysisService.php`, `ai/analysis.php` |
| RF13 | ✅ | `AssistantService.php`, `AIController.php`, `partials/chat.php` |
| RF14 bônus | ✅ | `HygieneController.php`, `hygiene/index.php` |
| RNF01 | ✅ | `Database.php`, `Auth.php`, `Csrf.php`, `Encryption.php`, `UploadService.php`, `AuditRepository.php` |
| RNF02 | ✅ | índices em `schema.sql`, paginação em `PatientRepository.php` |
| RNF03 | ✅ | `app.css`, semântica/ARIA nas views, texto + cor nas prioridades |
| RNF04 | ✅ | SSE em `MonitoringController.php` + fallback polling em `monitoring.js` |
| RNF05 | ✅ | `bin/backup.sh`, `docs/BACKUP_RESTORE.md` |
| RNF06 | ✅ | `AiProviderInterface.php`, `NullAiProvider.php`, timeouts e mensagens de fallback |
| RNF07 | ✅ | separação `Controllers/Services/Repositories/Core/Views` |
| RNF08 | ✅ | AES-256-GCM, finalidade/consentimento, auditoria e relatórios agregados |
| RNF09 | ✅ | `docs/MANUAL_USUARIO.md` |
