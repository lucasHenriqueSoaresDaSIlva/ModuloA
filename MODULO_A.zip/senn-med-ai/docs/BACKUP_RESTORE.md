# Backup e recuperação

## Backup automatizado

Execute:

```bash
./bin/backup.sh
```

O script usa `mysqldump`, compacta em `storage/backups/`, restringe a permissão do arquivo e remove backups com mais de 7 dias.

Exemplo de agendamento diário no Linux, 02:30:

```cron
30 2 * * * /caminho/senn-med-ai/bin/backup.sh >> /caminho/senn-med-ai/storage/logs/backup.log 2>&1
```

## Restauração

1. Pare escrita na aplicação ou coloque-a em manutenção.
2. Faça um backup do estado atual.
3. Restaure o arquivo escolhido:

```bash
gunzip -c storage/backups/senn_med_ai_YYYYMMDD_HHMMSS.sql.gz | mysql -h 127.0.0.1 -u root -p senn_med_ai
```

4. Rode `php bin/healthcheck.php`.
5. Valide login, pacientes, mapa, alertas e dashboard antes de liberar o sistema.
