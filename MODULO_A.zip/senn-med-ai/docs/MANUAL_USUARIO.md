# Manual do Usuário — SENN MED-AI

> Protótipo educacional. As classificações e saídas de IA não substituem protocolo institucional, julgamento profissional ou software clínico certificado.

## 1. Administrador hospitalar

1. Entre com o perfil **Administrador**.
2. Em **Infraestrutura**, cadastre leitos e consultórios com setor, tipo, equipamentos, status e manutenção.
3. Em **Profissionais**, cadastre CRM/COREN, validade, especialidade, turno e disponibilidade.
4. Em **Usuários**, crie contas e vincule médicos/enfermeiros aos registros profissionais.
5. Use **Dashboard** para indicadores, PDF/Excel e alertas.
6. Use **Auditoria** para consultar acessos e alterações relacionados a prontuários e entidades sensíveis.
7. Use os módulos **IA & previsão** para demanda 7/30 dias, risco de estouro de tempo e análise operacional.

## 2. Recepcionista

1. Entre com o perfil **Recepcionista**.
2. Abra **Pacientes → Nova ficha**.
3. Registre dados pessoais, convênio, queixa, sinais vitais iniciais, alergias/comorbidades e finalidade/consentimento.
4. Salve. O paciente é enviado à fila de triagem mesmo se a API de IA estiver indisponível.
5. Para lotes, use **Importar CSV** e siga o cabeçalho exibido na tela.
6. Em **Higienização**, quando autorizado pelo fluxo local, marque o recurso como concluído após limpeza.

## 3. Enfermeiro de triagem

1. Entre com o perfil **Enfermeiro**.
2. Abra **Triagem** e selecione o paciente.
3. Confira sinais vitais, queixa, alergias e comorbidades.
4. Leia a sugestão determinística e, se disponível, o complemento da IA.
5. **Confirme ou altere** a classificação. Se alterar, justifique.
6. O sistema executa a alocação sugerida de médico/recurso e move o paciente para `aguardando_medico`.
7. Acompanhe **Tempo real**, **Alertas** e **Risco**. Toda decisão clínica continua sob responsabilidade profissional.

## 4. Médico

1. Entre com o perfil **Médico**.
2. Acompanhe **Tempo real** e atualize o estado para `em_atendimento` ou `medicacao` conforme o fluxo.
3. Abra **Desfecho** do atendimento.
4. Registre CID, evolução/conduta, prescrição/orientação e anexo opcional em PDF/JPG/PNG.
5. Ao registrar a alta, data/hora e usuário são capturados automaticamente e o leito/consultório vai para **higienização**.

## 5. SENN MED-AI Helper

O botão flutuante responde localmente a perguntas sobre leitos, fila e tempos do protocolo. Perguntas mais abertas podem usar a API externa. Se a IA falhar, o Helper informa modo manual e o restante do sistema continua funcionando.

## 6. Acessibilidade

- Navegação por `Tab` e `Shift+Tab`.
- Foco visual destacado.
- Classes de Manchester sempre exibem **texto + cor**, nunca cor isolada.
- Layout adapta-se a desktop, tablet e celular.

## 7. Suporte básico

- Erro de banco: confirme serviço MySQL e variáveis `DB_*` no `.env`.
- IA indisponível: confirme `AI_PROVIDER`, `AI_API_KEY`, modelo, extensão cURL e acesso à internet. O modo fallback é esperado e seguro.
- Upload recusado: use PDF/JPG/PNG dentro do limite `UPLOAD_MAX_BYTES`.
- SSE indisponível: a tela troca automaticamente para polling a cada 5 segundos.
