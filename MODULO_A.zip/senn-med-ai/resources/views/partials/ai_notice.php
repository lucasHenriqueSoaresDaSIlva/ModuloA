<div class="ai-notice" role="note" aria-label="Aviso clínico sobre inteligência artificial">
  <strong>Suporte à decisão clínica.</strong> Toda saída de IA é apenas apoio. A validação final cabe ao profissional habilitado e ao protocolo institucional.
</div>
