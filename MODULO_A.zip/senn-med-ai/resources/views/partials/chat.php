<button id="chatOpen" class="chat-open" type="button" aria-controls="chatPanel" aria-expanded="false">
  <span class="chat-open-mark" aria-hidden="true">AI</span>
  <span><strong>SENN MED-AI</strong><small>Assistente operacional</small></span>
</button>

<aside id="chatPanel" class="chat-panel" aria-label="Assistente SENN MED-AI Helper" hidden>
  <div class="chat-head">
    <div class="chat-head-brand">
      <span class="chat-ai-badge" aria-hidden="true">AI</span>
      <div><strong>SENN MED-AI Helper</strong><small>Assistente operacional do sistema</small></div>
    </div>
    <button id="chatClose" type="button" aria-label="Fechar assistente">×</button>
  </div>

  <div id="chatMessages" class="chat-messages" aria-live="polite">
    <div class="chat-message assistant">
      <strong>Como posso ajudar?</strong>
      <span>Consulte informações operacionais do sistema, como protocolo, fila, leitos e prontuários.</span>
      <div class="chat-examples">
        <button type="button" onclick="document.getElementById('chatQuestion').value='Como está a fila?';document.getElementById('chatForm').requestSubmit();">Como está a fila?</button>
        <button type="button" onclick="document.getElementById('chatQuestion').value='Quantos leitos estão livres?';document.getElementById('chatForm').requestSubmit();">Leitos disponíveis</button>
        <button type="button" onclick="document.getElementById('chatQuestion').value='Quais são os tempos do protocolo?';document.getElementById('chatForm').requestSubmit();">Tempos do protocolo</button>
      </div>
    </div>
  </div>

  <?php require BASE_PATH . '/resources/views/partials/ai_notice.php'; ?>

  <form id="chatForm" class="chat-form" novalidate>
    <label for="chatQuestion">Pergunta</label>
    <div class="chat-form-row">
      <textarea id="chatQuestion" rows="2" maxlength="500" placeholder="Digite sua pergunta..." required></textarea>
      <button id="chatSend" type="submit">Enviar</button>
    </div>
    <small>Enter envia · Shift + Enter quebra a linha</small>
  </form>
</aside>
