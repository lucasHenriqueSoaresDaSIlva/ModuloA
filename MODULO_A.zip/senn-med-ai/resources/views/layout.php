<?php
use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Core\View;
use App\Core\Url;

$flashes = Flash::pull();
$roleLabels = [
    'admin' => 'Administrador hospitalar',
    'doctor' => 'Médico',
    'nurse' => 'Enfermeiro de triagem',
    'receptionist' => 'Recepcionista',
];
$roleLabel = $currentUser ? ($roleLabels[$currentUser['role']] ?? $currentUser['role']) : '';
$initial = $currentUser ? mb_strtoupper(mb_substr((string)$currentUser['name'], 0, 1)) : 'S';
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= View::e($csrfToken) ?>">
  <meta name="theme-color" content="#0b1f36">
  <title><?= View::e($title ?? 'SENN MED-AI') ?> · SENN MED-AI</title>
  <link rel="stylesheet" href="/assets/css/app.css?v=4">
</head>
<body class="<?= $currentUser ? 'app-authenticated' : 'app-guest' ?>">
<a class="skip-link" href="#conteudo">Pular para o conteúdo</a>

<?php if ($currentUser): ?>
<div class="app-shell">
  <div id="navOverlay" class="nav-overlay" hidden></div>

  <aside id="mainNav" class="sidebar" aria-label="Navegação principal">
    <div class="sidebar-brand">
      <a class="brand" href="/dashboard" aria-label="SENN MED-AI, página inicial">
        <span class="brand-mark" aria-hidden="true">S</span>
        <span class="brand-copy">
          <strong>SENN MED-AI</strong>
          <small>Smart Care</small>
        </span>
      </a>
      <button id="navClose" class="sidebar-close" type="button" aria-label="Fechar menu">×</button>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section">
        <span class="nav-label">Operação</span>
        <a href="/dashboard"><span class="nav-dot"></span>Dashboard</a>
        <a href="/patients"><span class="nav-dot"></span>Pacientes</a>
        <?php if (Auth::can('admin','nurse','doctor')): ?><a href="/triage"><span class="nav-dot"></span>Triagem</a><?php endif; ?>
        <a href="/monitoring"><span class="nav-dot"></span>Tempo real</a>
        <?php if (Auth::can('admin','doctor','nurse')): ?><a href="/alerts"><span class="nav-dot"></span>Alertas</a><?php endif; ?>
        <?php if (Auth::can('admin','nurse','receptionist')): ?><a href="/hygiene"><span class="nav-dot"></span>Higienização</a><?php endif; ?>
      </div>

      <?php if (Auth::can('admin','doctor','nurse')): ?>
      <div class="nav-section">
        <span class="nav-label">Inteligência</span>
        <a href="/ai/forecast"><span class="nav-dot"></span>IA & previsão</a>
      </div>
      <?php endif; ?>

      <?php if (Auth::can('admin')): ?>
      <div class="nav-section">
        <span class="nav-label">Administração</span>
        <a href="/users"><span class="nav-dot"></span>Usuários</a>
        <a href="/professionals"><span class="nav-dot"></span>Profissionais</a>
        <a href="/infrastructure"><span class="nav-dot"></span>Infraestrutura</a>
        <a href="/audit"><span class="nav-dot"></span>Auditoria</a>
      </div>
      <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
      <div class="user-avatar" aria-hidden="true"><?= View::e($initial) ?></div>
      <div class="user-details">
        <strong><?= View::e($currentUser['name']) ?></strong>
        <span><?= View::e($roleLabel) ?></span>
      </div>
      <form action="/logout" method="post" class="logout-form">
        <?= Csrf::field() ?>
        <button class="logout-button" type="submit" title="Sair">Sair</button>
      </form>
    </div>
  </aside>

  <div class="app-main">
    <header class="app-topbar">
      <div class="topbar-left">
        <button id="navToggle" class="nav-toggle" type="button" aria-controls="mainNav" aria-expanded="false" aria-label="Abrir menu">
          <span></span><span></span><span></span>
        </button>
        <div class="topbar-title">
          <small>Central operacional</small>
          <strong><?= View::e($title ?? 'SENN MED-AI') ?></strong>
        </div>
      </div>
      <div class="topbar-right">
        <span class="system-pill"><i></i>Sistema online</span>
        <div class="topbar-user">
          <span class="mini-avatar" aria-hidden="true"><?= View::e($initial) ?></span>
          <div><strong><?= View::e($currentUser['name']) ?></strong><small><?= View::e($roleLabel) ?></small></div>
        </div>
      </div>
    </header>

    <main id="conteudo" class="content-container" tabindex="-1">
      <?php foreach ($flashes as $flash): ?>
        <div class="flash flash-<?= View::e($flash['type']) ?>" role="status"><?= View::e($flash['message']) ?></div>
      <?php endforeach; ?>
      <?= $content ?>
    </main>
  </div>
</div>
<?php else: ?>
<main id="conteudo" class="auth-container" tabindex="-1">
  <?php foreach ($flashes as $flash): ?>
    <div class="auth-flash flash flash-<?= View::e($flash['type']) ?>" role="status"><?= View::e($flash['message']) ?></div>
  <?php endforeach; ?>
  <?= $content ?>
</main>
<?php endif; ?>

<?php if ($currentUser): require BASE_PATH . '/resources/views/partials/chat.php'; endif; ?>
<script>window.__APP_BASE__ = <?= json_encode(Url::basePath(), JSON_UNESCAPED_SLASHES) ?>;</script>
<script src="/assets/js/app.js?v=4" defer></script>
</body>
</html>
