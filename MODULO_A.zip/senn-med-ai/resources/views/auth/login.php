<section class="auth-shell" aria-labelledby="loginTitle">
  <div class="auth-hero" aria-hidden="true">
    <div class="auth-hero-content">
      <div class="hero-brand"><span class="brand-mark">S</span><strong>SENN MED-AI</strong></div>
      <span class="eyebrow">Smart Care · Gestão Hospitalar</span>
      <h2>Decisões mais rápidas.<br>Fluxo hospitalar mais seguro.</h2>
      <p>Triagem, leitos, alertas e inteligência operacional em uma única plataforma.</p>
      <div class="hero-features">
        <div><span>01</span><strong>Monitoramento em tempo real</strong></div>
        <div><span>02</span><strong>Triagem Manchester assistida</strong></div>
        <div><span>03</span><strong>Gestão protegida e auditável</strong></div>
      </div>
    </div>
    <div class="hero-orbit orbit-one"></div>
    <div class="hero-orbit orbit-two"></div>
  </div>

  <div class="login-card">
    <div class="login-mobile-brand">
      <span class="brand-mark">S</span>
      <div><strong>SENN MED-AI</strong><small>Smart Care</small></div>
    </div>
    <div class="login-heading">
      <span class="eyebrow">Acesso protegido</span>
      <h1 id="loginTitle">Bem-vindo de volta</h1>
      <p>Entre com suas credenciais para acessar a central hospitalar.</p>
    </div>

    <form method="post" action="/login" class="login-form">
      <?= \App\Core\Csrf::field() ?>
      <label>
        <span>Identificador</span>
        <input name="identifier" autocomplete="username" placeholder="E-mail ou CRM/COREN" required>
      </label>
      <label>
        <span>Senha</span>
        <input type="password" name="password" autocomplete="current-password" placeholder="Digite sua senha" required>
      </label>
      <label>
        <span>Perfil de acesso</span>
        <select name="role" required>
          <option value="">Selecione seu perfil</option>
          <option value="admin">Administrador hospitalar</option>
          <option value="doctor">Médico</option>
          <option value="nurse">Enfermeiro de triagem</option>
          <option value="receptionist">Recepcionista</option>
        </select>
      </label>
      <button class="login-submit" type="submit">Entrar no sistema</button>
    </form>

    <div class="security-note">
      <span class="security-icon">✓</span>
      <span>Sessão protegida, acesso por perfil e auditoria de operações.</span>
    </div>
  </div>
</section>
