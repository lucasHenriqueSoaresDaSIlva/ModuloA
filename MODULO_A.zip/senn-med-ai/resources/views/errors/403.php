<section class="panel"><h1>Acesso negado</h1><p>Seu perfil não possui permissão para esta funcionalidade.</p><a class="button" href="/dashboard">Voltar ao dashboard</a></section>
