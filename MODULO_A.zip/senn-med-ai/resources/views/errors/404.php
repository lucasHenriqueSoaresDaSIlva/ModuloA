<section class="panel"><h1>Página não encontrada</h1><p>O recurso solicitado não existe ou não está mais disponível.</p><a class="button" href="/dashboard">Voltar ao dashboard</a></section>
