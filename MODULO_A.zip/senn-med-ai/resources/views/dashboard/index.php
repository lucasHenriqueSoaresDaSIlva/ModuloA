<?php use App\Core\View; $s=$metrics['summary']; ?>
<div class="page-head"><div><h1>Dashboard gerencial</h1><p>Indicadores agregados para apoiar a operação hospitalar.</p></div><div class="actions"><a class="button secondary" href="/reports/export?format=pdf&from=<?= View::e($metrics['from']) ?>&to=<?= View::e($metrics['to']) ?>">Exportar PDF</a><a class="button secondary" href="/reports/export?format=xls&from=<?= View::e($metrics['from']) ?>&to=<?= View::e($metrics['to']) ?>">Exportar Excel</a></div></div>
<form class="panel form-grid" method="get"><label>De<input type="date" name="from" value="<?= View::e($metrics['from']) ?>"></label><label>Até<input type="date" name="to" value="<?= View::e($metrics['to']) ?>"></label><div class="full"><button type="submit">Aplicar período</button></div></form>
<section class="grid grid-4" aria-label="Indicadores principais">
  <div class="metric"><small>Atendimentos</small><strong><?= View::e($s['total'] ?? 0) ?></strong></div>
  <div class="metric"><small>Tempo médio de espera</small><strong><?= View::e($s['avg_wait'] ?? 0) ?> min</strong></div>
  <div class="metric"><small>Dentro do protocolo</small><strong><?= View::e($s['within_protocol'] ?? 0) ?>%</strong></div>
  <div class="metric"><small>Ocupação atual</small><strong><?= View::e($s['occupancy'] ?? 0) ?>%</strong></div>
</section>
<section class="grid grid-2" style="margin-top:1rem">
  <div class="panel"><h2>Atendimentos por gravidade</h2><canvas class="chart" data-chart='<?= View::e(json_encode($metrics['bySeverity'],JSON_UNESCAPED_UNICODE)) ?>' aria-label="Gráfico de atendimentos por gravidade"></canvas></div>
  <div class="panel"><h2>Atendimentos por setor</h2><canvas class="chart" data-chart='<?= View::e(json_encode($metrics['bySector'],JSON_UNESCAPED_UNICODE)) ?>' aria-label="Gráfico de atendimentos por setor"></canvas></div>
</section>
<section class="panel"><div class="page-head"><div><h2>Alertas abertos</h2><p>Os cinco mais recentes.</p></div><a href="/alerts">Ver todos</a></div><?php if(!$alerts): ?><p class="muted">Nenhum alerta aberto.</p><?php else: ?><div class="grid"><?php foreach($alerts as $a): ?><article class="panel alert-<?= View::e($a['severity']) ?>"><strong><?= View::e($a['message']) ?></strong><div class="muted"><?= View::e($a['created_at']) ?></div></article><?php endforeach; ?></div><?php endif; ?></section>
<script src="/assets/js/dashboard.js" defer></script>
