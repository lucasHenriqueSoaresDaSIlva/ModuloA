<?php
declare(strict_types=1);

putenv('AI_CLINICAL_CONTEXT_ENABLED=false');
putenv('APP_ENCRYPTION_KEY=base64:RmAZPCtUCP1Md3lbup+ZtlhYaFFsavFbhivibJFjets=');
require dirname(__DIR__) . '/config/bootstrap.php';

use App\Core\Encryption;
use App\Core\Validator;
use App\Services\AllocationService;
use App\Services\PdfReportService;
use App\Services\TriageService;

$tests = [];
$pass = 0;
$fail = 0;

$test = function (string $name, callable $fn) use (&$tests, &$pass, &$fail): void {
    try {
        $fn();
        $tests[] = "[OK] {$name}";
        $pass++;
    } catch (Throwable $e) {
        $tests[] = "[FALHA] {$name}: {$e->getMessage()}";
        $fail++;
    }
};

$assert = static function (bool $condition, string $message = 'assertion failed'): void {
    if (!$condition) throw new RuntimeException($message);
};

$test('Criptografia AES-256-GCM faz round-trip', function () use ($assert) {
    $plain = 'Dado clínico sensível de teste';
    $encrypted = Encryption::encrypt($plain);
    $assert($encrypted !== $plain, 'texto não foi criptografado');
    $assert(Encryption::decrypt($encrypted) === $plain, 'texto não voltou ao original');
});

$test('Hash determinístico ignora máscara de CPF', function () use ($assert) {
    $assert(Encryption::deterministicHash('123.456.789-00') === Encryption::deterministicHash('12345678900'));
});

$test('Validação de faixas numéricas', function () use ($assert) {
    $assert(Validator::intRange('98', 50, 100));
    $assert(!Validator::intRange('120', 50, 100));
});

$test('Triagem crítica sugere vermelho', function () use ($assert) {
    $enc = ['systolic'=>75,'diastolic'=>45,'temperature'=>36.8,'heart_rate'=>155,'spo2'=>88,'chief_complaint'=>'paciente inconsciente','comorbidities'=>'','checkin_at'=>date('Y-m-d H:i:s')];
    $r = (new TriageService())->suggest($enc);
    $assert($r['suggested_color'] === 'vermelho', 'esperado vermelho');
});

$test('Triagem estável pode ficar azul', function () use ($assert) {
    $enc = ['systolic'=>120,'diastolic'=>80,'temperature'=>36.5,'heart_rate'=>72,'spo2'=>99,'chief_complaint'=>'solicita avaliação sem sintomas de alarme','comorbidities'=>'','checkin_at'=>date('Y-m-d H:i:s')];
    $r = (new TriageService())->suggest($enc);
    $assert($r['suggested_color'] === 'azul', 'esperado azul');
});

$test('Comorbidade eleva um nível no conjunto demonstrativo', function () use ($assert) {
    $enc = ['systolic'=>120,'diastolic'=>80,'temperature'=>36.5,'heart_rate'=>72,'spo2'=>99,'chief_complaint'=>'avaliação sem sinais de alarme','comorbidities'=>'diabetes tipo 2','checkin_at'=>date('Y-m-d H:i:s')];
    $r = (new TriageService())->suggest($enc);
    $assert($r['suggested_color'] === 'verde', 'esperado verde');
});

$test('Score de fila prioriza gravidade', function () use ($assert) {
    $svc = new AllocationService();
    $now = date('Y-m-d H:i:s');
    $assert($svc->priorityScore('vermelho',$now) > $svc->priorityScore('azul',$now));
});

$test('Gerador de PDF produz assinatura válida', function () use ($assert) {
    $pdf = (new PdfReportService())->build('Teste', ['Linha 1','Linha 2']);
    $assert(str_starts_with($pdf, '%PDF-1.4'), 'assinatura PDF ausente');
    $assert(str_contains($pdf, '%%EOF'), 'EOF ausente');
});

foreach ($tests as $line) echo $line, PHP_EOL;
echo PHP_EOL, "Resultado: {$pass} aprovado(s), {$fail} falha(s).", PHP_EOL;
exit($fail === 0 ? 0 : 1);
